<script setup lang="ts">
import { useAppRouter } from '@app/router'

const router = useAppRouter()
</script>

<template>
  <main class="empty-page">
    <p class="eyebrow">404</p>
    <h1>页面不存在</h1>
    <button class="primary-button" type="button" @click="router.replace('/')">返回工作台</button>
  </main>
</template>

<style scoped>
.empty-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 60vh;
  text-align: center;
}

.eyebrow {
  margin: 0 0 16px;
  font-size: 64px;
  font-weight: 800;
  background: linear-gradient(135deg, #b58cff, #6750a4);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.empty-page h1 {
  margin: 0 0 24px;
  font-size: 24px;
  color: #f6f2ff;
}

.primary-button {
  padding: 12px 28px;
  border: none;
  border-radius: 8px;
  background: linear-gradient(135deg, #6750a4 0%, #6750a4 100%);
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
}

.primary-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(103, 80, 164, 0.3);
}
</style>
