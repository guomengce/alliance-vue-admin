<script setup lang="ts">
import { ref, computed } from 'vue'

interface Template {
  id: string
  name: string
  type: 'sms' | 'email' | 'push'
  status: 'active' | 'inactive'
  variables: string[]
  content: string
  createdAt: string
}

interface Notification {
  id: string
  type: 'single' | 'batch'
  template: string
  recipients: string | number
  status: 'pending' | 'sending' | 'completed' | 'failed'
  createdAt: string
}

const templates = ref<Template[]>([
  { 
    id: 'TPL001', 
    name: '投资成功通知', 
    type: 'push', 
    status: 'active',
    variables: ['{username}', '{amount}', '{package}'],
    content: '尊敬的{username}，您的{package}投资已成功，金额${amount}。感谢您的信任！',
    createdAt: '2024-05-20'
  },
  { 
    id: 'TPL002', 
    name: '佣金到账通知', 
    type: 'push', 
    status: 'active',
    variables: ['{username}', '{amount}'],
    content: '尊敬的{username}，您的佣金${amount}已到账，请查收！',
    createdAt: '2024-05-18'
  },
  { 
    id: 'TPL003', 
    name: '提现审核通知', 
    type: 'email', 
    status: 'active',
    variables: ['{username}', '{amount}'],
    content: '尊敬的{username}，您的提现申请${amount}已通过审核，预计1-3个工作日到账。',
    createdAt: '2024-05-15'
  },
  { 
    id: 'TPL004', 
    name: '系统维护通知', 
    type: 'sms', 
    status: 'inactive',
    variables: ['{time}'],
    content: '系统将于{time}进行维护，预计持续2小时，期间暂停所有服务。',
    createdAt: '2024-05-10'
  },
])

const notifications = ref<Notification[]>([
  { id: 'NOT001', type: 'batch', template: '投资成功通知', recipients: 156, status: 'completed', createdAt: '2024-05-28 10:30:00' },
  { id: 'NOT002', type: 'single', template: '佣金到账通知', recipients: '张三', status: 'completed', createdAt: '2024-05-28 09:15:00' },
  { id: 'NOT003', type: 'batch', template: '提现审核通知', recipients: 23, status: 'sending', createdAt: '2024-05-28 11:00:00' },
])

const activeTab = ref('templates')
const searchQuery = ref('')
const showSendModal = ref(false)
const sendType = ref<'single' | 'batch'>('single')
const selectedTemplate = ref('')
const singleUser = ref('')
const batchCount = ref(0)

const filteredTemplates = computed(() => {
  return templates.value.filter(t => 
    t.name.includes(searchQuery.value) || t.id.includes(searchQuery.value)
  )
})

const typeLabels: Record<string, string> = {
  sms: '短信',
  email: '邮件',
  push: '推送',
}

const statusLabels: Record<string, string> = {
  pending: '待发送',
  sending: '发送中',
  completed: '已完成',
  failed: '失败',
}

const toggleTemplateStatus = (template: Template) => {
  template.status = template.status === 'active' ? 'inactive' : 'active'
}

const openSendModal = () => {
  showSendModal.value = true
}

const closeSendModal = () => {
  showSendModal.value = false
}

const sendNotification = () => {
  alert('通知已发送')
  closeSendModal()
}
</script>

<template>
  <div class="notifications-page">
    <!-- Header -->
    <div class="page-header">
      <div class="header-left">
        <h2>通知管理</h2>
        <p>模板管理、手动群发/单发操作表单</p>
      </div>
      <div class="header-actions">
        <button class="btn-primary" @click="openSendModal">
          <i class="ri-send-plane-line" aria-hidden="true"></i>
          发送通知
        </button>
      </div>
    </div>

    <!-- Tabs -->
    <div class="tabs">
      <button 
        class="tab-btn" 
        :class="{ active: activeTab === 'templates' }"
        @click="activeTab = 'templates'"
      >
        📝 模板管理
      </button>
      <button 
        class="tab-btn" 
        :class="{ active: activeTab === 'history' }"
        @click="activeTab = 'history'"
      >
        📜 发送记录
      </button>
    </div>

    <!-- Templates Section -->
    <div v-show="activeTab === 'templates'" class="templates-section">
      <div class="section-header">
        <div class="search-box">
          <i class="ri-search-line" aria-hidden="true"></i>
          <input 
            v-model="searchQuery" 
            type="text" 
            placeholder="搜索模板名称..."
          />
        </div>
        <button class="btn-secondary">
          <i class="ri-add-line" aria-hidden="true"></i>
          新建模板
        </button>
      </div>

      <div class="templates-list">
        <div 
          v-for="template in filteredTemplates" 
          :key="template.id" 
          class="template-card"
          :class="{ 'is-inactive': template.status === 'inactive' }"
        >
          <div class="template-header">
            <div class="template-info">
              <code>{{ template.id }}</code>
              <h3>{{ template.name }}</h3>
            </div>
            <div class="template-tags">
              <span class="type-tag">{{ typeLabels[template.type] }}</span>
              <span 
                class="status-tag" 
                :class="template.status"
              >
                {{ template.status === 'active' ? '启用' : '停用' }}
              </span>
            </div>
          </div>

          <div class="template-content">
            <p>{{ template.content }}</p>
          </div>

          <div class="template-variables">
            <span class="variables-label">可用变量:</span>
            <div class="variables-list">
              <span 
                v-for="(variable, index) in template.variables" 
                :key="index" 
                class="variable-tag"
              >
                {{ variable }}
              </span>
            </div>
          </div>

          <div class="template-footer">
            <span>创建于 {{ template.createdAt }}</span>
            <div class="template-actions">
              <button class="action-btn">✏ 编辑</button>
              <button 
                class="action-btn" 
                :class="{ 'danger': template.status === 'active' }"
                @click="toggleTemplateStatus(template)"
              >
                <i :class="template.status === 'active' ? 'ri-pause-line' : 'ri-play-line'" aria-hidden="true"></i>
                {{ template.status === 'active' ? '停用' : '启用' }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- History Section -->
    <div v-show="activeTab === 'history'" class="history-section">
      <div class="table-container">
        <table class="history-table">
          <thead>
            <tr>
              <th>通知ID</th>
              <th>发送类型</th>
              <th>模板</th>
              <th>接收者</th>
              <th>状态</th>
              <th>发送时间</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="notification in notifications" :key="notification.id">
              <td><code>{{ notification.id }}</code></td>
              <td>
                <span 
                  class="type-tag"
                  :class="notification.type"
                >
                  {{ notification.type === 'single' ? '单发' : '群发' }}
                </span>
              </td>
              <td>{{ notification.template }}</td>
              <td>
                {{ typeof notification.recipients === 'number' ? notification.recipients + ' 人' : notification.recipients }}
              </td>
              <td>
                <span 
                  class="status-tag" 
                  :class="notification.status"
                >
                  {{ statusLabels[notification.status] }}
                </span>
              </td>
              <td>{{ notification.createdAt }}</td>
            </tr>
          </tbody>
        </table>

        <div v-if="notifications.length === 0" class="empty-state">
          <i class="ri-inbox-line" aria-hidden="true"></i>
          <p>暂无发送记录</p>
        </div>
      </div>
    </div>

    <!-- Send Modal -->
    <div v-if="showSendModal" class="modal-overlay" @click="closeSendModal">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <h3>发送通知</h3>
          <button class="close-btn" @click="closeSendModal">
            <i class="ri-close-line" aria-hidden="true"></i>
          </button>
        </div>
        <div class="modal-body">
          <div class="send-form">
            <div class="form-group">
              <label>发送类型</label>
              <div class="radio-group">
                <label>
                  <input 
                    v-model="sendType" 
                    type="radio" 
                    value="single"
                  />
                  <span>单发</span>
                </label>
                <label>
                  <input 
                    v-model="sendType" 
                    type="radio" 
                    value="batch"
                  />
                  <span>群发</span>
                </label>
              </div>
            </div>

            <div class="form-group">
              <label>选择模板</label>
              <select v-model="selectedTemplate">
                <option value="">请选择模板</option>
                <option 
                  v-for="template in templates" 
                  :key="template.id" 
                  :value="template.id"
                >
                  {{ template.name }}
                </option>
              </select>
            </div>

            <div v-if="sendType === 'single'" class="form-group">
              <label>接收用户</label>
              <input 
                v-model="singleUser" 
                type="text" 
                placeholder="请输入用户名或ID"
              />
            </div>

            <div v-if="sendType === 'batch'" class="form-group">
              <label>接收人数</label>
              <input 
                v-model.number="batchCount" 
                type="number" 
                min="1"
                placeholder="请输入群发人数"
              />
            </div>

            <div class="form-group">
              <label>预览内容</label>
              <textarea readonly class="preview-text">
尊敬的用户，您的投资已成功，金额$1000。感谢您的信任！
              </textarea>
            </div>

            <div class="form-actions">
              <button class="btn-secondary" @click="closeSendModal">取消</button>
              <button class="btn-primary" @click="sendNotification">发送通知</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.notifications-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.header-left h2 {
  margin: 0 0 6px;
  font-size: 24px;
  font-weight: 700;
  color: #f6f2ff;
}

.header-left p {
  margin: 0;
  color: #8e8798;
  font-size: 14px;
}

.btn-primary {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  border: none;
  border-radius: 8px;
  background: linear-gradient(135deg, #6750a4 0%, #6750a4 100%);
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(103, 80, 164, 0.3);
}

/* Tabs */
.tabs {
  display: flex;
  gap: 8px;
}

.tab-btn {
  padding: 12px 24px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  color: #8e8798;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
}

.tab-btn.active {
  border-color: #6750a4;
  background: rgba(103, 80, 164, 0.2);
  color: #d8d0e4;
}

/* Templates Section */
.section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;
}

.search-box {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
}

.search-box span {
  color: #8e8798;
  font-size: 14px;
}

.search-box input {
  border: none;
  background: transparent;
  color: #f6f2ff;
  font-size: 14px;
  outline: none;
  width: 200px;
}

.search-box input::placeholder {
  color: #8e8798;
}

.btn-secondary {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #d8d0e4;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
}

.btn-secondary:hover {
  background: rgb(255 255 255 / 6%);
}

/* Templates List */
.templates-list {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
}

.template-card {
  padding: 20px;
  border-radius: 12px;
  background: #16121d;
  border: 1px solid rgb(255 255 255 / 8%);
}

.template-card.is-inactive {
  opacity: 0.7;
}

.template-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: 12px;
}

.template-info code {
  padding: 4px 8px;
  border-radius: 4px;
  background: #211c29;
  color: #8e8798;
  font-family: monospace;
  font-size: 12px;
}

.template-info h3 {
  margin: 8px 0 0;
  font-size: 16px;
  color: #f6f2ff;
}

.template-tags {
  display: flex;
  gap: 8px;
}

.type-tag {
  padding: 4px 10px;
  border-radius: 4px;
  background: #211c29;
  color: #8e8798;
  font-size: 12px;
}

.status-tag {
  padding: 4px 10px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
}

.status-tag.active {
  background: rgba(20, 184, 166, 0.15);
  color: #14b8a6;
}

.status-tag.inactive {
  background: rgba(142, 135, 152, 0.15);
  color: #8e8798;
}

.template-content p {
  margin: 0;
  padding: 12px;
  border-radius: 8px;
  background: #211c29;
  color: #d8d0e4;
  font-size: 14px;
  line-height: 1.6;
}

.template-variables {
  margin-top: 12px;
}

.variables-label {
  color: #8e8798;
  font-size: 12px;
}

.variables-list {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 8px;
}

.variable-tag {
  padding: 4px 10px;
  border-radius: 4px;
  background: rgba(251, 191, 36, 0.15);
  color: #fbbf24;
  font-family: monospace;
  font-size: 12px;
}

.template-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 16px;
  padding-top: 12px;
  border-top: 1px solid rgb(255 255 255 / 6%);
}

.template-footer span {
  color: #8e8798;
  font-size: 12px;
}

.template-actions {
  display: flex;
  gap: 8px;
}

.action-btn {
  padding: 6px 12px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 6px;
  background: #211c29;
  color: #8e8798;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
}

.action-btn:hover {
  background: rgb(255 255 255 / 6%);
}

.action-btn.danger {
  border-color: rgba(248, 113, 113, 0.3);
  color: #f87171;
}

.action-btn.danger:hover {
  background: rgba(248, 113, 113, 0.1);
}

/* History Table */
.table-container {
  border-radius: 12px;
  background: #16121d;
  border: 1px solid rgb(255 255 255 / 8%);
  overflow: hidden;
}

.history-table {
  width: 100%;
  border-collapse: collapse;
}

.history-table th {
  padding: 16px;
  text-align: left;
  background: #211c29;
  color: #8e8798;
  font-size: 13px;
  font-weight: 600;
}

.history-table td {
  padding: 16px;
  border-bottom: 1px solid rgb(255 255 255 / 6%);
  color: #d8d0e4;
}

.history-table td code {
  padding: 4px 8px;
  border-radius: 4px;
  background: #211c29;
  color: #8e8798;
  font-family: monospace;
  font-size: 12px;
}

.type-tag.single {
  background: rgba(20, 184, 166, 0.15);
  color: #14b8a6;
}

.type-tag.batch {
  background: rgba(96, 165, 250, 0.15);
  color: #60a5fa;
}

.status-tag.pending {
  background: rgba(251, 191, 36, 0.15);
  color: #fbbf24;
}

.status-tag.sending {
  background: rgba(96, 165, 250, 0.15);
  color: #60a5fa;
}

.status-tag.completed {
  background: rgba(20, 184, 166, 0.15);
  color: #14b8a6;
}

.status-tag.failed {
  background: rgba(248, 113, 113, 0.15);
  color: #f87171;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 48px;
  color: #8e8798;
}

.empty-state span {
  font-size: 48px;
}

/* Modal */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.7);
  z-index: 1000;
}

.modal-content {
  width: min(90%, 500px);
  border-radius: 12px;
  background: #16121d;
  border: 1px solid rgb(255 255 255 / 8%);
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
  overflow: hidden;
}

.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 24px;
  border-bottom: 1px solid rgb(255 255 255 / 6%);
}

.modal-header h3 {
  margin: 0;
  font-size: 18px;
  color: #f6f2ff;
}

.close-btn {
  padding: 6px;
  border: none;
  border-radius: 6px;
  background: #211c29;
  color: #8e8798;
  font-size: 16px;
  cursor: pointer;
}

.modal-body {
  padding: 24px;
}

.send-form {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: #d8d0e4;
  font-size: 14px;
  font-weight: 600;
}

.radio-group {
  display: flex;
  gap: 24px;
}

.radio-group label {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 0;
  color: #8e8798;
  font-weight: 400;
  cursor: pointer;
}

.form-group input,
.form-group select {
  width: 100%;
  padding: 12px 14px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #f6f2ff;
  font-size: 14px;
  outline: none;
}

.form-group input:focus,
.form-group select:focus {
  border-color: #6750a4;
}

.form-group input::placeholder {
  color: #8e8798;
}

.preview-text {
  width: 100%;
  height: 100px;
  padding: 12px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #d8d0e4;
  font-size: 14px;
  resize: none;
}

.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
}

/* Responsive */
@media (max-width: 900px) {
  .templates-list {
    grid-template-columns: 1fr;
  }

  .history-table {
    display: block;
    overflow-x: auto;
  }
}
</style>
