<script setup lang="ts">
import { ref, computed } from 'vue'

const activeTab = ref('team')
const dateRange = ref('7days')

const teamData = ref([
  { name: '张三', level: 'L5', members: 1256, volume: 520000, commission: 15600 },
  { name: '李四', level: 'L4', members: 892, volume: 380000, commission: 11400 },
  { name: '王五', level: 'L3', members: 567, volume: 240000, commission: 7200 },
  { name: '赵六', level: 'L3', members: 432, volume: 190000, commission: 5700 },
  { name: '孙七', level: 'L2', members: 289, volume: 120000, commission: 3600 },
])

const commissionData = ref([
  { date: '05-23', amount: 45000 },
  { date: '05-24', amount: 52000 },
  { date: '05-25', amount: 38000 },
  { date: '05-26', amount: 61000 },
  { date: '05-27', amount: 49000 },
  { date: '05-28', amount: 55000 },
  { date: '05-29', amount: 58000 },
])

const operationData = ref([
  { metric: '新增用户', value: 156, change: '+12%' },
  { metric: '新增投资', value: 45, change: '+8%' },
  { metric: '总投资额', value: 2850000, change: '+15%' },
  { metric: '平均投资', value: 5800, change: '+5%' },
])

const maxCommission = computed(() => {
  return Math.max(...commissionData.value.map(d => d.amount))
})

const exportReport = (format: 'excel' | 'csv') => {
  alert(`${format.toUpperCase()} 报表已导出`)
}
</script>

<template>
  <div class="reports-page">
    <!-- Header -->
    <div class="page-header">
      <div class="header-left">
        <h2>数据报表</h2>
        <p>团队/佣金/运营分析图表、Excel/CSV导出按钮</p>
      </div>
      <div class="header-actions">
        <select v-model="dateRange">
          <option value="7days">近7天</option>
          <option value="30days">近30天</option>
          <option value="90days">近90天</option>
          <option value="custom">自定义</option>
        </select>
        <button class="btn-export" @click="exportReport('excel')">
          <i class="ri-file-excel-2-line" aria-hidden="true"></i>
          Excel
        </button>
        <button class="btn-export" @click="exportReport('csv')">
          <i class="ri-file-text-line" aria-hidden="true"></i>
          CSV
        </button>
      </div>
    </div>

    <!-- Tabs -->
    <div class="tabs">
      <button 
        class="tab-btn" 
        :class="{ active: activeTab === 'team' }"
        @click="activeTab = 'team'"
      >
        <i class="ri-team-line" aria-hidden="true"></i>
        团队报表
      </button>
      <button 
        class="tab-btn" 
        :class="{ active: activeTab === 'commission' }"
        @click="activeTab = 'commission'"
      >
        <i class="ri-coins-line" aria-hidden="true"></i>
        佣金报表
      </button>
      <button 
        class="tab-btn" 
        :class="{ active: activeTab === 'operation' }"
        @click="activeTab = 'operation'"
      >
        <i class="ri-line-chart-line" aria-hidden="true"></i>
        运营报表
      </button>
    </div>

    <!-- Team Report -->
    <div v-show="activeTab === 'team'" class="report-panel">
      <div class="panel-header">
        <h3>团队业绩排行榜</h3>
      </div>

      <div class="team-stats">
        <div class="team-stat">
          <span class="stat-value">{{ teamData.reduce((sum, t) => sum + t.members, 0).toLocaleString() }}</span>
          <span class="stat-label">总团队人数</span>
        </div>
        <div class="team-stat">
          <span class="stat-value">${{ teamData.reduce((sum, t) => sum + t.volume, 0).toLocaleString() }}</span>
          <span class="stat-label">总业绩</span>
        </div>
        <div class="team-stat">
          <span class="stat-value">${{ teamData.reduce((sum, t) => sum + t.commission, 0).toLocaleString() }}</span>
          <span class="stat-label">总佣金</span>
        </div>
      </div>

      <div class="team-table-container">
        <table class="team-table">
          <thead>
            <tr>
              <th>排名</th>
              <th>用户</th>
              <th>等级</th>
              <th>团队人数</th>
              <th>业绩金额</th>
              <th>佣金收入</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(member, index) in teamData" :key="member.name">
              <td>
                <span 
                  class="rank-badge" 
                  :class="{ 'gold': index === 0, 'silver': index === 1, 'bronze': index === 2 }"
                >
                  {{ index + 1 }}
                </span>
              </td>
              <td>{{ member.name }}</td>
              <td><span class="level-badge">{{ member.level }}</span></td>
              <td>{{ member.members.toLocaleString() }}</td>
              <td>${{ member.volume.toLocaleString() }}</td>
              <td class="commission-cell">${{ member.commission.toLocaleString() }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Commission Report -->
    <div v-show="activeTab === 'commission'" class="report-panel">
      <div class="panel-header">
        <h3>佣金趋势分析</h3>
      </div>

      <div class="chart-container">
        <div class="chart-header">
          <span>佣金金额趋势</span>
          <span class="chart-total">
            合计: ${{ commissionData.reduce((sum, c) => sum + c.amount, 0).toLocaleString() }}
          </span>
        </div>
        <div class="bar-chart">
          <div 
            v-for="(data, index) in commissionData" 
            :key="index" 
            class="bar-item"
          >
            <div 
              class="bar" 
              :style="{ height: (data.amount / maxCommission * 100) + '%' }"
            >
              <span class="bar-value">${{ data.amount.toLocaleString() }}</span>
            </div>
            <span class="bar-label">{{ data.date }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Operation Report -->
    <div v-show="activeTab === 'operation'" class="report-panel">
      <div class="panel-header">
        <h3>运营数据分析</h3>
      </div>

      <div class="operation-cards">
        <div 
          v-for="data in operationData" 
          :key="data.metric" 
          class="operation-card"
        >
          <div class="card-icon"><i class="ri-bar-chart-box-line" aria-hidden="true"></i></div>
          <div class="card-content">
            <span class="metric-name">{{ data.metric }}</span>
            <span class="metric-value">
              {{ typeof data.value === 'number' && data.value >= 1000 ? '$' + data.value.toLocaleString() : data.value }}
            </span>
            <span 
              class="metric-change" 
              :class="{ 'positive': data.change.startsWith('+'), 'negative': data.change.startsWith('-') }"
            >
              {{ data.change }}
            </span>
          </div>
        </div>
      </div>

      <div class="chart-container">
        <div class="chart-header">
          <span>用户增长趋势</span>
        </div>
        <div class="line-chart">
          <svg viewBox="0 0 400 150" class="chart-svg">
            <defs>
              <linearGradient id="lineGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" style="stop-color:#6750a4;stop-opacity:0.3" />
                <stop offset="100%" style="stop-color:#6750a4;stop-opacity:0" />
              </linearGradient>
            </defs>
            <path 
              d="M 0 120 Q 50 100 100 110 T 200 80 T 300 60 T 400 40" 
              fill="none" 
              stroke="#6750a4" 
              stroke-width="3"
            />
            <path 
              d="M 0 120 Q 50 100 100 110 T 200 80 T 300 60 T 400 40 L 400 150 L 0 150 Z" 
              fill="url(#lineGradient)"
            />
            <circle cx="0" cy="120" r="5" fill="#6750a4" />
            <circle cx="100" cy="110" r="5" fill="#6750a4" />
            <circle cx="200" cy="80" r="5" fill="#6750a4" />
            <circle cx="300" cy="60" r="5" fill="#6750a4" />
            <circle cx="400" cy="40" r="5" fill="#6750a4" />
          </svg>
          <div class="chart-labels">
            <span>05-25</span>
            <span>05-26</span>
            <span>05-27</span>
            <span>05-28</span>
            <span>05-29</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.reports-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.header-left h2 {
  margin: 0 0 6px;
  font-size: 24px;
  font-weight: 700;
  color: #f6f2ff;
}

.header-left p {
  margin: 0;
  color: #8e8798;
  font-size: 14px;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 12px;
}

.header-actions select {
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #f6f2ff;
  font-size: 14px;
  cursor: pointer;
}

.btn-export {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #d8d0e4;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
}

.btn-export:hover {
  background: rgb(255 255 255 / 6%);
}

/* Tabs */
.tabs {
  display: flex;
  gap: 8px;
}

.tab-btn {
  padding: 12px 24px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  color: #8e8798;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
}

.tab-btn.active {
  border-color: #6750a4;
  background: rgba(103, 80, 164, 0.2);
  color: #d8d0e4;
}

/* Report Panel */
.report-panel {
  padding: 24px;
  border-radius: 12px;
  background: #16121d;
  border: 1px solid rgb(255 255 255 / 8%);
}

.panel-header h3 {
  margin: 0 0 20px;
  font-size: 18px;
  color: #f6f2ff;
}

/* Team Stats */
.team-stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
  margin-bottom: 20px;
}

.team-stat {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  border-radius: 12px;
  background: #211c29;
}

.team-stat .stat-value {
  font-size: 28px;
  font-weight: 700;
  color: #fff;
}

.team-stat .stat-label {
  margin-top: 4px;
  color: #8e8798;
  font-size: 13px;
}

/* Team Table */
.team-table-container {
  overflow-x: auto;
}

.team-table {
  width: 100%;
  border-collapse: collapse;
}

.team-table th {
  padding: 16px;
  text-align: left;
  background: #211c29;
  color: #8e8798;
  font-size: 13px;
  font-weight: 600;
}

.team-table td {
  padding: 16px;
  border-bottom: 1px solid rgb(255 255 255 / 6%);
  color: #d8d0e4;
}

.rank-badge {
  display: flex;
  width: 28px;
  height: 28px;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background: #211c29;
  color: #8e8798;
  font-size: 14px;
  font-weight: 700;
}

.rank-badge.gold {
  background: linear-gradient(135deg, #fbbf24, #f59e0b);
  color: #fff;
}

.rank-badge.silver {
  background: linear-gradient(135deg, #9ca3af, #6b7280);
  color: #fff;
}

.rank-badge.bronze {
  background: linear-gradient(135deg, #d97706, #b45309);
  color: #fff;
}

.level-badge {
  padding: 4px 10px;
  border-radius: 4px;
  background: #211c29;
  color: #8e8798;
  font-size: 12px;
  font-weight: 600;
}

.commission-cell {
  color: #14b8a6;
  font-weight: 600;
}

/* Chart Container */
.chart-container {
  margin-top: 20px;
}

.chart-header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
}

.chart-header span:first-child {
  color: #8e8798;
  font-size: 14px;
}

.chart-total {
  color: #b58cff;
  font-size: 16px;
  font-weight: 700;
}

/* Bar Chart */
.bar-chart {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  height: 200px;
  padding: 20px 0;
  border-bottom: 2px solid rgb(255 255 255 / 8%);
}

.bar-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 12%;
}

.bar {
  width: 100%;
  min-height: 20px;
  border-radius: 8px 8px 0 0;
  background: linear-gradient(180deg, #b58cff 0%, #6750a4 100%);
  position: relative;
  transition: height 0.3s ease;
}

.bar:hover {
  opacity: 0.8;
}

.bar-value {
  position: absolute;
  top: -30px;
  left: 50%;
  transform: translateX(-50%);
  padding: 4px 8px;
  border-radius: 4px;
  background: #211c29;
  color: #fff;
  font-size: 11px;
  white-space: nowrap;
  opacity: 0;
  transition: opacity 0.2s ease;
}

.bar:hover .bar-value {
  opacity: 1;
}

.bar-label {
  margin-top: 8px;
  color: #8e8798;
  font-size: 12px;
}

/* Operation Cards */
.operation-cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}

.operation-card {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px;
  border-radius: 12px;
  background: #211c29;
}

.card-icon {
  display: flex;
  width: 48px;
  height: 48px;
  align-items: center;
  justify-content: center;
  border-radius: 12px;
  background: rgba(103, 80, 164, 0.2);
  color: #b58cff;
  font-size: 24px;
}

.card-content {
  flex: 1;
}

.metric-name {
  display: block;
  color: #8e8798;
  font-size: 13px;
}

.metric-value {
  display: block;
  margin-top: 4px;
  color: #fff;
  font-size: 24px;
  font-weight: 700;
}

.metric-change {
  display: inline-block;
  margin-top: 4px;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
}

.metric-change.positive {
  background: rgba(20, 184, 166, 0.15);
  color: #14b8a6;
}

.metric-change.negative {
  background: rgba(248, 113, 113, 0.15);
  color: #f87171;
}

/* Line Chart */
.line-chart {
  margin-top: 20px;
}

.chart-svg {
  width: 100%;
  height: 180px;
}

.chart-labels {
  display: flex;
  justify-content: space-between;
  margin-top: 8px;
  color: #8e8798;
  font-size: 12px;
}

/* Responsive */
@media (max-width: 900px) {
  .team-stats {
    grid-template-columns: repeat(2, 1fr);
  }

  .operation-cards {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 640px) {
  .team-stats {
    grid-template-columns: 1fr;
  }

  .operation-cards {
    grid-template-columns: 1fr;
  }
}
</style>
