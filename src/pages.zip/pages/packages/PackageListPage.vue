<script setup lang="ts">
import { ref, computed } from 'vue'

interface Package {
  id: string
  name: string
  code: string
  price: number
  minInvest: number
  maxInvest: number
  dailyReturn: number
  duration: number
  level: string
  status: 'active' | 'inactive'
  features: string[]
  params: Record<string, number>
}

const packages = ref<Package[]>([
  {
    id: 'PKG001',
    name: '套餐A',
    code: 'A',
    price: 1000,
    minInvest: 1000,
    maxInvest: 9999,
    dailyReturn: 0.8,
    duration: 30,
    level: 'L1',
    status: 'active',
    features: ['基础收益', '1层佣金', '基础客服'],
    params: { l1_rate: 10, l2_rate: 0, l3_rate: 0, l4_rate: 0, l5_rate: 0 },
  },
  {
    id: 'PKG002',
    name: '套餐B',
    code: 'B',
    price: 5000,
    minInvest: 10000,
    maxInvest: 49999,
    dailyReturn: 1.2,
    duration: 45,
    level: 'L2',
    status: 'active',
    features: ['高级收益', '2层佣金', 'VIP客服', '优先提现'],
    params: { l1_rate: 15, l2_rate: 8, l3_rate: 0, l4_rate: 0, l5_rate: 0 },
  },
  {
    id: 'PKG003',
    name: '套餐C',
    code: 'C',
    price: 20000,
    minInvest: 50000,
    maxInvest: 199999,
    dailyReturn: 1.8,
    duration: 60,
    level: 'L3',
    status: 'active',
    features: ['精英收益', '3层佣金', '专属客服', '快速提现', '专属通道'],
    params: { l1_rate: 20, l2_rate: 12, l3_rate: 6, l4_rate: 0, l5_rate: 0 },
  },
  {
    id: 'PKG004',
    name: '套餐D',
    code: 'D',
    price: 50000,
    minInvest: 200000,
    maxInvest: 499999,
    dailyReturn: 2.5,
    duration: 90,
    level: 'L4',
    status: 'active',
    features: ['尊享收益', '4层佣金', '1对1客服', '即时提现', 'VIP通道', '专属顾问'],
    params: { l1_rate: 25, l2_rate: 15, l3_rate: 10, l4_rate: 5, l5_rate: 0 },
  },
  {
    id: 'PKG005',
    name: '套餐E',
    code: 'E',
    price: 100000,
    minInvest: 500000,
    maxInvest: 9999999,
    dailyReturn: 3.5,
    duration: 120,
    level: 'L5',
    status: 'active',
    features: ['至尊收益', '5层佣金', '专属经理', '秒提', '极速通道', '专属方案', '月度返利'],
    params: { l1_rate: 30, l2_rate: 20, l3_rate: 15, l4_rate: 10, l5_rate: 5 },
  },
])

const searchQuery = ref('')
const levelFilter = ref('all')
const showFormModal = ref(false)
const editingPackage = ref<Package | null>(null)
const formData = ref({
  name: '',
  code: '',
  price: 0,
  minInvest: 0,
  maxInvest: 0,
  dailyReturn: 0,
  duration: 30,
  level: 'L1',
})

const filteredPackages = computed(() => {
  return packages.value.filter(pkg => {
    const matchesSearch = pkg.name.includes(searchQuery.value) || 
                         pkg.code.includes(searchQuery.value)
    const matchesLevel = levelFilter.value === 'all' || pkg.level === levelFilter.value
    return matchesSearch && matchesLevel
  })
})

const levelColors: Record<string, string> = {
  L1: '#64748b',
  L2: '#0d766e',
  L3: '#1d4f91',
  L4: '#9a6700',
  L5: '#6750a4',
}

const toggleStatus = (pkg: Package) => {
  pkg.status = pkg.status === 'active' ? 'inactive' : 'active'
}

const openAddModal = () => {
  editingPackage.value = null
  formData.value = {
    name: '',
    code: '',
    price: 0,
    minInvest: 0,
    maxInvest: 0,
    dailyReturn: 0,
    duration: 30,
    level: 'L1',
  }
  showFormModal.value = true
}

const openEditModal = (pkg: Package) => {
  editingPackage.value = pkg
  formData.value = {
    name: pkg.name,
    code: pkg.code,
    price: pkg.price,
    minInvest: pkg.minInvest,
    maxInvest: pkg.maxInvest,
    dailyReturn: pkg.dailyReturn,
    duration: pkg.duration,
    level: pkg.level,
  }
  showFormModal.value = true
}

const closeModal = () => {
  showFormModal.value = false
  editingPackage.value = null
}

const savePackage = () => {
  if (editingPackage.value) {
    Object.assign(editingPackage.value, formData.value)
  } else {
    const newPkg: Package = {
      ...formData.value,
      id: `PKG${String(packages.value.length + 1).padStart(3, '0')}`,
      status: 'active',
      features: [],
      params: { l1_rate: 10, l2_rate: 0, l3_rate: 0, l4_rate: 0, l5_rate: 0 },
    }
    packages.value.push(newPkg)
  }
  closeModal()
}

const deletePackage = (pkg: Package) => {
  if (confirm(`确定要删除套餐 ${pkg.name} 吗？`)) {
    packages.value = packages.value.filter(p => p.id !== pkg.id)
  }
}
</script>

<template>
  <div class="packages-page">
    <!-- Header -->
    <div class="page-header">
      <div class="header-left">
        <h2>套餐管理</h2>
        <p>管理平台会员套餐，支持套餐CRUD及动态参数配置</p>
      </div>
      <div class="header-actions">
        <button class="btn-primary" @click="openAddModal">
          <i class="ri-add-line" aria-hidden="true"></i>
          新建套餐
        </button>
      </div>
    </div>

    <!-- Filters -->
    <div class="filters-bar">
      <div class="search-box">
        <i class="ri-search-line" aria-hidden="true"></i>
        <input 
          v-model="searchQuery" 
          type="text" 
          placeholder="搜索套餐名称或代码..."
        />
      </div>
      <div class="filter-group">
        <select v-model="levelFilter">
          <option value="all">全部等级</option>
          <option value="L1">L1</option>
          <option value="L2">L2</option>
          <option value="L3">L3</option>
          <option value="L4">L4</option>
          <option value="L5">L5</option>
        </select>
      </div>
    </div>

    <!-- Packages Grid -->
    <div class="packages-grid">
      <div 
        v-for="pkg in filteredPackages" 
        :key="pkg.id" 
        class="package-card"
        :class="{ 'is-inactive': pkg.status === 'inactive' }"
      >
        <div class="card-header">
          <div class="package-badge" :style="{ background: levelColors[pkg.level] }">
            {{ pkg.level }}
          </div>
          <div class="package-info">
            <h3>{{ pkg.name }}</h3>
            <span class="package-code">{{ pkg.id }}</span>
          </div>
          <span 
            class="status-badge" 
            :class="pkg.status"
          >
            {{ pkg.status === 'active' ? '启用' : '停用' }}
          </span>
        </div>

        <div class="card-body">
          <div class="price-section">
            <span class="price-label">套餐价格</span>
            <span class="price-value">${{ pkg.price.toLocaleString() }}</span>
          </div>

          <div class="invest-range">
            <span>投资区间</span>
            <span class="range-value">${{ pkg.minInvest.toLocaleString() }} - ${{ pkg.maxInvest.toLocaleString() }}</span>
          </div>

          <div class="stats-row">
            <div class="stat-item">
              <span class="stat-label">日收益率</span>
              <span class="stat-value">{{ pkg.dailyReturn }}%</span>
            </div>
            <div class="stat-item">
              <span class="stat-label">周期</span>
              <span class="stat-value">{{ pkg.duration }}天</span>
            </div>
          </div>

          <div class="features-section">
            <span class="section-title">权益</span>
            <div class="features-list">
              <span 
                v-for="(feature, index) in pkg.features" 
                :key="index" 
                class="feature-tag"
              >
                {{ feature }}
              </span>
            </div>
          </div>
        </div>

        <div class="card-footer">
          <button 
            class="action-btn status-btn" 
            @click="toggleStatus(pkg)"
          >
            <i :class="pkg.status === 'active' ? 'ri-pause-line' : 'ri-play-line'" aria-hidden="true"></i>
            {{ pkg.status === 'active' ? '停用' : '启用' }}
          </button>
          <button 
            class="action-btn edit-btn" 
            @click="openEditModal(pkg)"
          >
            <i class="ri-edit-line" aria-hidden="true"></i>
            编辑
          </button>
          <button 
            class="action-btn delete-btn" 
            @click="deletePackage(pkg)"
          >
            <i class="ri-delete-bin-line" aria-hidden="true"></i>
            删除
          </button>
        </div>
      </div>
    </div>

    <!-- Form Modal -->
    <div v-if="showFormModal" class="modal-overlay" @click="closeModal">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <div>
            <h3>{{ editingPackage ? '编辑套餐' : '新建套餐' }}</h3>
            <p>{{ editingPackage ? '修改已有套餐信息' : '创建新的会员套餐' }}</p>
          </div>
          <button class="close-btn" @click="closeModal">
            <i class="ri-close-line" aria-hidden="true"></i>
          </button>
        </div>
        <div class="modal-body">
          <form class="package-form" @submit.prevent="savePackage">
            <div class="form-row">
              <div class="form-group">
                <label>套餐名称</label>
                <input 
                  v-model="formData.name" 
                  type="text" 
                  placeholder="如：套餐A"
                  required
                />
              </div>
              <div class="form-group">
                <label>套餐代码</label>
                <input 
                  v-model="formData.code" 
                  type="text" 
                  placeholder="如：A"
                  required
                />
              </div>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label>套餐价格 ($)</label>
                <input 
                  v-model.number="formData.price" 
                  type="number" 
                  min="0"
                  required
                />
              </div>
              <div class="form-group">
                <label>最低投资 ($)</label>
                <input 
                  v-model.number="formData.minInvest" 
                  type="number" 
                  min="0"
                  required
                />
              </div>
              <div class="form-group">
                <label>最高投资 ($)</label>
                <input 
                  v-model.number="formData.maxInvest" 
                  type="number" 
                  min="0"
                  required
                />
              </div>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label>日收益率 (%)</label>
                <input 
                  v-model.number="formData.dailyReturn" 
                  type="number" 
                  min="0" 
                  step="0.1"
                  required
                />
              </div>
              <div class="form-group">
                <label>投资周期 (天)</label>
                <input 
                  v-model.number="formData.duration" 
                  type="number" 
                  min="1"
                  required
                />
              </div>
              <div class="form-group">
                <label>等级</label>
                <select v-model="formData.level">
                  <option value="L1">L1</option>
                  <option value="L2">L2</option>
                  <option value="L3">L3</option>
                  <option value="L4">L4</option>
                  <option value="L5">L5</option>
                </select>
              </div>
            </div>

            <div class="form-row">
              <div class="form-group full">
                <label>佣金比例配置</label>
                <div class="commission-config">
                  <div 
                    v-for="i in 5" 
                    :key="i" 
                    class="commission-item"
                  >
                    <span>L{{ i }} 佣金</span>
                    <input 
                      type="number" 
                      :value="editingPackage?.params[`l${i}_rate`] || 0"
                      disabled
                      class="disabled-input"
                    />
                    <span>%</span>
                  </div>
                </div>
              </div>
            </div>

            <div class="form-actions">
              <button type="button" class="btn-secondary" @click="closeModal">取消</button>
              <button type="submit" class="btn-primary">保存</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.packages-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 100%;
  color: #f6f2ff;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.header-left h2 {
  margin: 0 0 6px;
  color: #fff;
  font-size: 24px;
  font-weight: 700;
}

.header-left p {
  margin: 0;
  color: #8e8798;
  font-size: 14px;
}

.btn-primary {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  border: none;
  border-radius: 8px;
  background: linear-gradient(135deg, #6750a4 0%, #6750a4 100%);
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 24px rgb(103 80 164 / 30%);
}

/* Filters */
.filters-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background:
    linear-gradient(180deg, rgb(255 255 255 / 3.5%), rgb(255 255 255 / 1.2%)),
    #16121d;
  box-shadow: inset 0 1px 0 rgb(255 255 255 / 4%);
}

.search-box {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #a99ec0;
}

.search-box i {
  color: #b58cff;
  font-size: 14px;
}

.search-box input {
  border: none;
  background: transparent;
  color: #f6f2ff;
  font-size: 14px;
  outline: none;
  width: 200px;
}

.search-box input::placeholder {
  color: #777181;
}

.filter-group select {
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #f6f2ff;
  font-size: 14px;
  cursor: pointer;
}

/* Packages Grid */
.packages-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
  gap: 20px;
}

.package-card {
  border-radius: 8px;
  background: #16121d;
  border: 1px solid rgb(255 255 255 / 8%);
  overflow: hidden;
  transition: all 0.2s ease;
  box-shadow: 0 18px 50px rgb(0 0 0 / 26%);
}

.package-card:hover {
  box-shadow: 0 24px 60px rgb(0 0 0 / 36%);
  transform: translateY(-2px);
}

.package-card.is-inactive {
  opacity: 0.6;
}

.card-header {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px;
  border-bottom: 1px solid rgb(255 255 255 / 6%);
  background: #211c29;
}

.package-badge {
  display: flex;
  width: 36px;
  height: 36px;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  color: #fff;
  font-size: 14px;
  font-weight: 700;
}

.package-info {
  flex: 1;
}

.package-info h3 {
  margin: 0;
  color: #fff;
  font-size: 18px;
  font-weight: 700;
}

.package-code {
  color: #8e8798;
  font-size: 12px;
}

.status-badge {
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

.status-badge.active {
  background: rgba(13, 118, 110, 0.2);
  color: #14b8a6;
}

.status-badge.inactive {
  background: rgba(100, 116, 139, 0.2);
  color: #94a3b8;
}

.card-body {
  padding: 16px;
}

.price-section {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  padding-bottom: 12px;
  border-bottom: 1px solid rgb(255 255 255 / 6%);
}

.price-label {
  color: #8e8798;
  font-size: 13px;
}

.price-value {
  color: #c4b5fd;
  font-size: 24px;
  font-weight: 700;
}

.invest-range {
  display: flex;
  justify-content: space-between;
  margin-bottom: 16px;
}

.invest-range span:first-child {
  color: #8e8798;
  font-size: 13px;
}

.range-value {
  color: #d8d0e4;
  font-size: 13px;
  font-weight: 600;
}

.stats-row {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
  margin-bottom: 16px;
}

.stat-item {
  display: flex;
  flex-direction: column;
  padding: 12px;
  border-radius: 8px;
  background: #211c29;
}

.stat-label {
  color: #8e8798;
  font-size: 12px;
}

.stat-value {
  margin-top: 4px;
  color: #fff;
  font-size: 16px;
  font-weight: 700;
}

.features-section {
  margin-bottom: 8px;
}

.section-title {
  display: block;
  margin-bottom: 8px;
  color: #8e8798;
  font-size: 12px;
}

.features-list {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.feature-tag {
  padding: 4px 10px;
  border-radius: 4px;
  background: rgba(103, 80, 164, 0.2);
  color: #c4b5fd;
  font-size: 11px;
}

.card-footer {
  display: flex;
  gap: 8px;
  padding: 12px 16px;
  border-top: 1px solid rgb(255 255 255 / 6%);
  background: #211c29;
}

.action-btn {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 10px;
  border: none;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.status-btn {
  background: rgba(13, 118, 110, 0.15);
  color: #14b8a6;
}

.status-btn:hover {
  background: rgba(13, 118, 110, 0.25);
}

.edit-btn {
  background: rgba(59, 130, 246, 0.15);
  color: #60a5fa;
}

.edit-btn:hover {
  background: rgba(59, 130, 246, 0.25);
}

.delete-btn {
  background: rgba(180, 35, 24, 0.15);
  color: #f87171;
}

.delete-btn:hover {
  background: rgba(180, 35, 24, 0.25);
}

/* Modal */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgb(0 0 0 / 62%);
  z-index: 1000;
}

.modal-content {
  width: min(90%, 600px);
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  box-shadow: 0 24px 60px rgb(0 0 0 / 42%);
  overflow: hidden;
}

.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 24px;
  border-bottom: 1px solid rgb(255 255 255 / 8%);
}

.modal-header h3 {
  margin: 0 0 4px;
  color: #fff;
  font-size: 18px;
}

.modal-header p {
  margin: 0;
  color: #8e8798;
  font-size: 13px;
}

.close-btn {
  padding: 6px;
  border: none;
  border-radius: 6px;
  background: rgb(255 255 255 / 6%);
  color: #bfb6ce;
  font-size: 16px;
  cursor: pointer;
}

.modal-body {
  padding: 24px;
}

.package-form {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.form-row {
  display: flex;
  gap: 16px;
}

.form-group {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.form-group.full {
  flex: 1 1 100%;
}

.form-group label {
  margin-bottom: 6px;
  color: #aaa3b6;
  font-size: 13px;
  font-weight: 600;
}

.form-group input,
.form-group select {
  padding: 10px 14px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #f6f2ff;
  font-size: 14px;
  outline: none;
}

.form-group input:focus,
.form-group select:focus {
  border-color: #6750a4;
}

.disabled-input {
  background: #16121d;
  color: #8e8798;
}

.commission-config {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 12px;
}

.commission-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  padding: 12px;
  border-radius: 8px;
  background: #211c29;
}

.commission-item span:first-child {
  color: #8e8798;
  font-size: 12px;
}

.commission-item input {
  width: 60px;
  text-align: center;
}

.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 16px;
}

.btn-secondary {
  padding: 10px 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #d8d0e4;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-secondary:hover {
  background: rgb(103 80 164 / 18%);
  color: #fff;
}

/* Responsive */
@media (max-width: 900px) {
  .packages-grid {
    grid-template-columns: 1fr;
  }

  .filters-bar {
    flex-direction: column;
    gap: 12px;
  }

  .form-row {
    flex-direction: column;
  }

  .commission-config {
    grid-template-columns: repeat(3, 1fr);
  }
}

@media (max-width: 640px) {
  .search-box input {
    width: 100%;
  }

  .commission-config {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>