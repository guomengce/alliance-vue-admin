# pages

Route-level pages live here, such as `login`, `dashboard`, and `not-found`.

Pages are allowed to compose modules and shared UI, but they should not contain reusable business logic.
