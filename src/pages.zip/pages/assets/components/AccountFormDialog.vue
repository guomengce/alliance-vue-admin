<script setup lang="ts">
import { reactive, watch } from 'vue';
import { User, Message, Phone } from '@element-plus/icons-vue';

interface Account {
  id?: number;
  username: string;
  email: string;
  phone: string;
  accountType: '个人账户' | '企业账户';
  trustStatus: '已认证' | '未认证';
  status: '正常' | '禁用';
  registerTime?: string;
}

const props = defineProps<{
  visible: boolean;
  editData?: Account | null;
}>();

const emit = defineEmits<{
  'update:visible': [value: boolean];
  submit: [data: Partial<Account>];
}>();

// 表单数据
const form = reactive<Account>({
  id: undefined,
  username: '',
  email: '',
  phone: '',
  accountType: '个人账户',
  trustStatus: '未认证',
  status: '正常',
});

// 表单验证错误
const errors = reactive({
  username: '',
  email: '',
  phone: '',
});

// 清除错误
const clearErrors = () => {
  errors.username = '';
  errors.email = '';
  errors.phone = '';
};

// 重置表单
const resetForm = () => {
  form.id = undefined;
  form.username = '';
  form.email = '';
  form.phone = '';
  form.accountType = '个人账户';
  form.trustStatus = '未认证';
  form.status = '正常';
  clearErrors();
};

// 监听编辑数据变化
watch(
  () => props.editData,
  (newData) => {
    if (newData) {
      form.id = newData.id;
      form.username = newData.username;
      form.email = newData.email;
      form.phone = newData.phone;
      form.accountType = newData.accountType;
      form.trustStatus = newData.trustStatus;
      form.status = newData.status;
    } else {
      resetForm();
    }
  }
);

// 监听 visible 变化，关闭时重置表单
watch(
  () => props.visible,
  (newVal) => {
    if (!newVal) {
      resetForm();
    }
  }
);

// 表单验证
const validate = (): boolean => {
  clearErrors();
  let isValid = true;

  if (!form.username.trim()) {
    errors.username = '请输入用户名';
    isValid = false;
  } else if (form.username.length < 3) {
    errors.username = '用户名至少需要3个字符';
    isValid = false;
  }

  if (!form.email.trim()) {
    errors.email = '请输入邮箱';
    isValid = false;
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
    errors.email = '请输入有效的邮箱地址';
    isValid = false;
  }

  if (!form.phone.trim()) {
    errors.phone = '请输入手机号';
    isValid = false;
  } else if (!/^1[3-9]\d{9}$/.test(form.phone)) {
    errors.phone = '请输入有效的手机号';
    isValid = false;
  }

  return isValid;
};

// 提交表单
const handleSubmit = () => {
  if (validate()) {
    emit('submit', { ...form });
    emit('update:visible', false);
  }
};

// 关闭对话框
const handleClose = () => {
  emit('update:visible', false);
};
</script>

<template>
  <el-dialog
    :title="form.id ? '编辑账户' : '新增账户'"
    :visible="visible"
    :close-on-click-modal="false"
    width="500px"
    @close="handleClose"
  >
    <el-form :model="form" label-width="100px" class="account-form">
      <!-- 用户名 -->
      <el-form-item label="用户名" :error="errors.username">
        <el-input
          v-model="form.username"
          placeholder="请输入用户名"
          :prefix-icon="User"
        />
      </el-form-item>

      <!-- 邮箱 -->
      <el-form-item label="邮箱" :error="errors.email">
        <el-input
          v-model="form.email"
          placeholder="请输入邮箱"
          :prefix-icon="Message"
        />
      </el-form-item>

      <!-- 手机号 -->
      <el-form-item label="手机号" :error="errors.phone">
        <el-input
          v-model="form.phone"
          placeholder="请输入手机号"
          :prefix-icon="Phone"
        />
      </el-form-item>

      <!-- 账户类型 -->
      <el-form-item label="账户类型">
        <el-select v-model="form.accountType" placeholder="请选择账户类型">
          <el-option label="个人账户" value="个人账户" />
          <el-option label="企业账户" value="企业账户" />
        </el-select>
      </el-form-item>

      <!-- 信托认证 -->
      <el-form-item label="信托认证">
        <el-select v-model="form.trustStatus" placeholder="请选择信托认证状态">
          <el-option label="已认证" value="已认证" />
          <el-option label="未认证" value="未认证" />
        </el-select>
      </el-form-item>

      <!-- 状态 -->
      <el-form-item label="状态">
        <el-select v-model="form.status" placeholder="请选择状态">
          <el-option label="正常" value="正常" />
          <el-option label="禁用" value="禁用" />
        </el-select>
      </el-form-item>
    </el-form>

    <template #footer>
      <el-button type="default" @click="handleClose">取消</el-button>
      <el-button type="primary" @click="handleSubmit">
        {{ form.id ? '保存修改' : '确认新增' }}
      </el-button>
    </template>
  </el-dialog>
</template>

<style scoped>
.account-form {
  padding: 10px 0;
}

.account-form :deep(.el-form-item) {
  margin-bottom: 20px;
}
</style>
