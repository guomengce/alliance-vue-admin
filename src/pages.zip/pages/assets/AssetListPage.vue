<script setup lang="ts">
import { ref, reactive } from 'vue'
import { Download, Plus, Refresh, Delete } from '@element-plus/icons-vue'
import AccountFormDialog from './components/AccountFormDialog.vue'

// Mock数据
interface Account {
  id: number
  username: string
  email: string
  phone: string
  accountType: '个人账户' | '企业账户'
  trustStatus: '已认证' | '未认证'
  status: '正常' | '禁用'
  registerTime: string
}

// 对话框状态
const dialogVisible = ref(false)
const editData = ref<Account | null>(null)

const accounts = ref<Account[]>([
  {
    id: 10001,
    username: 'john_doe',
    email: 'john@example.com',
    phone: '138****1234',
    accountType: '个人账户',
    trustStatus: '已认证',
    status: '正常',
    registerTime: '2024-05-20 10:30:45',
  },
  {
    id: 10002,
    username: 'alice_chen',
    email: 'alice@example.com',
    phone: '139****6678',
    accountType: '企业账户',
    trustStatus: '未认证',
    status: '正常',
    registerTime: '2024-05-19 15:20:11',
  },
  {
    id: 10002,
    username: 'alice_chen',
    email: 'alice@example.com',
    phone: '138****6678',
    accountType: '企业账户',
    trustStatus: '未认证',
    status: '正常',
    registerTime: '2024-05-15 09:20:11',
  },
  {
    id: 10003,
    username: 'tom_li',
    email: 'tom@example.com',
    phone: '137****9012',
    accountType: '个人账户',
    trustStatus: '已认证',
    status: '禁用',
    registerTime: '2024-05-18 08:15:33',
  },
  {
    id: 10004,
    username: 'emma_wang',
    email: 'emma@example.com',
    phone: '136****3456',
    accountType: '个人账户',
    trustStatus: '已认证',
    status: '正常',
    registerTime: '2024-05-17 14:22:08',
  },
  {
    id: 10004,
    username: 'emma_wang',
    email: 'emma@example.com',
    phone: '136****3456',
    accountType: '个人账户',
    trustStatus: '未认证',
    status: '正常',
    registerTime: '2024-05-17 14:22:08',
  },
  {
    id: 10005,
    username: 'kevin_zhang',
    email: 'kevin@example.com',
    phone: '135****7890',
    accountType: '企业账户',
    trustStatus: '已认证',
    status: '正常',
    registerTime: '2024-05-16 11:06:27',
  },
  {
    id: 10006,
    username: 'sophia_liu',
    email: 'sophia@example.com',
    phone: '134****5678',
    accountType: '个人账户',
    trustStatus: '未认证',
    status: '禁用',
    registerTime: '2024-05-15 16:45:19',
  },
  {
    id: 10007,
    username: 'michael_zhou',
    email: 'michael@example.com',
    phone: '133****2468',
    accountType: '个人账户',
    trustStatus: '已认证',
    status: '正常',
    registerTime: '2024-05-14 12:33:00',
  },
  {
    id: 10007,
    username: 'michael_zhou',
    email: 'michael@example.com',
    phone: '133****2468',
    accountType: '个人账户',
    trustStatus: '已认证',
    status: '正常',
    registerTime: '2024-05-14 12:33:00',
  },
  {
    id: 10008,
    username: 'olivia_xu',
    email: 'olivia@example.com',
    phone: '132****3577',
    accountType: '企业账户',
    trustStatus: '已认证',
    status: '正常',
    registerTime: '2024-05-13 08:30:55',
  },
])

const total = ref(1256)
const currentPage = ref(1)
const pageSize = ref(10)

// 搜索表单
const searchForm = reactive({
  keyword: '',
  accountType: '',
  status: '',
  trustStatus: '',
  startTime: '',
  endTime: '',
})

// 下拉选项
const accountTypeOptions = [
  { label: '请选择账户类型', value: '' },
  { label: '个人账户', value: '个人账户' },
  { label: '企业账户', value: '企业账户' },
]

const statusOptions = [
  { label: '请选择状态', value: '' },
  { label: '正常', value: '正常' },
  { label: '禁用', value: '禁用' },
]

const trustStatusOptions = [
  { label: '请选择信托认证状态', value: '' },
  { label: '已认证', value: '已认证' },
  { label: '未认证', value: '未认证' },
]

// 选中的行
const selectedRows = ref<number[]>([])

// 获取信托认证状态样式
const getTrustStatusClass = (status: string) => {
  return status === '已认证' ? 'trust-certified' : 'trust-not-certified'
}

// 获取状态样式
const getStatusClass = (status: string) => {
  return status === '正常' ? 'status-active' : 'status-disabled'
}

// 编辑账户
const handleEdit = (row: Account) => {
  editData.value = row
  dialogVisible.value = true
}

// 删除账户
const handleDelete = (row: Account) => {
  if (confirm(`确定要删除账户 ${row.username} 吗？`)) {
    const index = accounts.value.findIndex((a) => a.id === row.id)
    if (index !== -1) {
      accounts.value.splice(index, 1)
    }
  }
}

// 搜索
const handleSearch = () => {
  console.log('搜索条件:', searchForm)
}

// 重置
const handleReset = () => {
  searchForm.keyword = ''
  searchForm.accountType = ''
  searchForm.status = ''
  searchForm.trustStatus = ''
  searchForm.startTime = ''
  searchForm.endTime = ''
}

// 导出
const handleExport = () => {
  console.log('导出数据')
}

// 新增账户
const handleAdd = () => {
  editData.value = null
  dialogVisible.value = true
}

// 处理表单提交
const handleFormSubmit = (data: Partial<Account>) => {
  if (data.id) {
    // 编辑模式
    const index = accounts.value.findIndex((a) => a.id === data.id)
    if (index !== -1) {
      const existing = accounts.value[index]
      accounts.value[index] = {
        id: data.id,
        username: data.username ?? existing.username,
        email: data.email ?? existing.email,
        phone: data.phone ?? existing.phone,
        accountType: (data.accountType as Account['accountType']) ?? existing.accountType,
        trustStatus: (data.trustStatus as Account['trustStatus']) ?? existing.trustStatus,
        status: (data.status as Account['status']) ?? existing.status,
        registerTime: existing.registerTime,
      }
    }
  } else {
    // 新增模式
    const newId = Math.max(...accounts.value.map((a) => a.id)) + 1
    accounts.value.unshift({
      id: newId,
      username: data.username || '',
      email: data.email || '',
      phone: data.phone || '',
      accountType: (data.accountType as Account['accountType']) || '个人账户',
      trustStatus: (data.trustStatus as Account['trustStatus']) || '未认证',
      status: (data.status as Account['status']) || '正常',
      registerTime: new Date().toLocaleString('zh-CN'),
    })
    total.value++
  }
}

// 刷新
const handleRefresh = () => {
  console.log('刷新数据')
}

// 批量删除
const handleBatchDelete = () => {
  if (selectedRows.value.length === 0) {
    alert('请先选择要删除的账户')
    return
  }
  if (confirm(`确定要删除选中的 ${selectedRows.value.length} 个账户吗？`)) {
    accounts.value = accounts.value.filter((a) => !selectedRows.value.includes(a.id))
    selectedRows.value = []
  }
}

// 分页
const handlePageChange = (page: number) => {
  currentPage.value = page
}

const handleSizeChange = (size: number) => {
  pageSize.value = size
  currentPage.value = 1
}
</script>

<template>
  <div class="account-list-page">
    <!-- 页面头部 -->
    <div class="page-header">
      <div class="header-left">
        <h1 class="page-title">账户列表</h1>
      </div>
      <div class="header-right">
        <el-button type="default" :icon="Download" @click="handleExport"> 导出 </el-button>
        <el-button type="primary" :icon="Plus" @click="handleAdd"> 新增账户 </el-button>
      </div>
    </div>

    <!-- 搜索区域 -->
    <el-card class="search-card">
      <div class="search-row">
        <el-form :model="searchForm" inline>
          <el-form-item label="关键词">
            <el-input
              v-model="searchForm.keyword"
              placeholder="用户名 / 邮箱 / 手机号"
              class="search-input"
            />
          </el-form-item>
          <el-form-item label="账户类型">
            <el-select
              v-model="searchForm.accountType"
              placeholder="请选择账户类型"
              class="search-select"
            >
              <el-option
                v-for="option in accountTypeOptions"
                :key="option.value"
                :label="option.label"
                :value="option.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="状态">
            <el-select v-model="searchForm.status" placeholder="请选择状态" class="search-select">
              <el-option
                v-for="option in statusOptions"
                :key="option.value"
                :label="option.label"
                :value="option.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="信托认证">
            <el-select
              v-model="searchForm.trustStatus"
              placeholder="请选择信托认证状态"
              class="search-select"
            >
              <el-option
                v-for="option in trustStatusOptions"
                :key="option.value"
                :label="option.label"
                :value="option.value"
              />
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <div class="search-row">
        <el-form :model="searchForm" inline>
          <el-form-item label="注册时间">
            <el-date-picker
              v-model="searchForm.startTime"
              type="datetime"
              placeholder="开始日期"
              class="date-picker"
            />
            <span class="date-separator">—</span>
            <el-date-picker
              v-model="searchForm.endTime"
              type="datetime"
              placeholder="结束日期"
              class="date-picker"
            />
          </el-form-item>
          <el-form-item>
            <el-button type="default" @click="handleReset">重置</el-button>
            <el-button type="primary" @click="handleSearch">查询</el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-card>

    <!-- 表格区域 -->
    <el-card class="table-card">
      <div class="table-header">
        <span class="data-count">共 {{ total }} 条数据</span>
        <div class="table-actions">
          <el-button type="default" :icon="Refresh" @click="handleRefresh" circle />
          <el-button type="danger" :icon="Delete" @click="handleBatchDelete"> 批量删除 </el-button>
        </div>
      </div>

      <el-table
        :data="accounts"
        :selectable="(row: Account) => row.status !== '禁用'"
        @selection-change="
          (val: Account[]) => {
            selectedRows = val.map((r) => r.id)
          }
        "
        border
        stripe
        :header-cell-style="{ background: '#f8f9fa', color: '#495057', fontWeight: '600' }"
      >
        <el-table-column type="selection" width="50" />
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="username" label="用户名" min-width="120" />
        <el-table-column prop="email" label="邮箱" min-width="180" />
        <el-table-column prop="phone" label="手机号" width="120" />
        <el-table-column prop="accountType" label="账户类型" width="100" />
        <el-table-column prop="trustStatus" label="信托认证" width="100">
          <template #default="scope">
            <span :class="['status-tag', getTrustStatusClass(scope.row.trustStatus)]">
              {{ scope.row.trustStatus }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="80">
          <template #default="scope">
            <span :class="['status-tag', getStatusClass(scope.row.status)]">
              {{ scope.row.status }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="registerTime" label="注册时间" width="180" />
        <el-table-column label="操作" width="120">
          <template #default="scope">
            <el-button type="text" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button type="text" class="delete-btn" @click="handleDelete(scope.row)"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination-container">
        <div class="pagination-left">
          <span>每页显示</span>
          <el-select v-model="pageSize" @change="handleSizeChange" class="page-size-select">
            <el-option label="10" :value="10" />
            <el-option label="20" :value="20" />
            <el-option label="50" :value="50" />
            <el-option label="100" :value="100" />
          </el-select>
          <span>条</span>
        </div>
        <div class="pagination-right">
          <el-pagination
            :current-page="currentPage"
            :page-size="pageSize"
            :total="total"
            :page-sizes="[10, 20, 50, 100]"
            layout="prev, pager, next, jumper"
            @current-change="handlePageChange"
          />
        </div>
      </div>
    </el-card>

    <!-- 新增/编辑对话框 -->
    <AccountFormDialog
      v-model:visible="dialogVisible"
      :edit-data="editData"
      @submit="handleFormSubmit"
    />
  </div>
</template>

<style scoped>
.account-list-page {
  padding: 0;
  min-height: 100%;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.page-title {
  font-size: 22px;
  font-weight: 600;
  color: #f6f2ff;
  margin: 0;
}

.header-right {
  display: flex;
  gap: 12px;
}

.search-card {
  margin-bottom: 24px;
  border-radius: 8px;
  background: #16121d;
  border: 1px solid rgb(255 255 255 / 8%);
}

.search-card :deep(.el-card__body) {
  padding: 0;
}

.search-row {
  display: flex;
  align-items: center;
  padding: 16px 20px;
}

.search-row:first-child {
  border-bottom: 1px dashed rgb(255 255 255 / 6%);
}

.search-input {
  width: 240px;
}

.search-input :deep(.el-input__wrapper) {
  background: #211c29;
  border: 1px solid rgb(255 255 255 / 8%);
}

.search-input :deep(.el-input__inner) {
  color: #f6f2ff;
}

.search-select {
  width: 160px;
}

.search-select :deep(.el-select__wrapper) {
  background: #211c29;
  border: 1px solid rgb(255 255 255 / 8%);
}

.search-select :deep(.el-select__placeholder) {
  color: #8e8798;
}

.search-select :deep(.el-select__label) {
  color: #f6f2ff;
}

.search-select :deep(.el-select-dropdown) {
  background: #16121d;
  border: 1px solid rgb(255 255 255 / 8%);
}

.search-select :deep(.el-select-dropdown__item) {
  color: #d8d0e4;
}

.search-select :deep(.el-select-dropdown__item:hover) {
  background: rgb(255 255 255 / 6%);
}

.date-picker {
  width: 180px;
}

.date-picker :deep(.el-date-editor) {
  background: #211c29;
  border: 1px solid rgb(255 255 255 / 8%);
}

.date-picker :deep(.el-date-editor input) {
  color: #f6f2ff;
}

.date-separator {
  margin: 0 8px;
  color: #8e8798;
}

.table-card {
  border-radius: 8px;
  background: #16121d;
  border: 1px solid rgb(255 255 255 / 8%);
}

.table-card :deep(.el-card__body) {
  padding: 0;
}

.table-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  padding: 20px;
  padding-bottom: 16px;
  border-bottom: 1px solid rgb(255 255 255 / 6%);
}

.data-count {
  font-size: 14px;
  color: #8e8798;
}

.table-actions {
  display: flex;
  gap: 12px;
}

.status-tag {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
}

.trust-certified {
  background-color: rgba(20, 184, 166, 0.15);
  color: #14b8a6;
}

.trust-not-certified {
  background-color: rgba(248, 113, 113, 0.15);
  color: #f87171;
}

.status-active {
  background-color: rgba(20, 184, 166, 0.15);
  color: #14b8a6;
}

.status-disabled {
  background-color: rgba(142, 135, 152, 0.15);
  color: #8e8798;
}

.delete-btn {
  color: #f87171;
}

.delete-btn:hover {
  color: #fca5a5;
}

.pagination-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 20px;
  padding: 16px 20px;
  border-top: 1px solid rgb(255 255 255 / 6%);
}

.pagination-left {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #8e8798;
}

.page-size-select {
  width: 80px;
}

.page-size-select :deep(.el-select__wrapper) {
  background: #211c29;
  border: 1px solid rgb(255 255 255 / 8%);
}

.pagination-right {
  display: flex;
  align-items: center;
}

.pagination-right :deep(.el-pagination) {
  color: #8e8798;
}

.pagination-right :deep(.el-pagination button) {
  color: #8e8798;
  background: #211c29;
  border: 1px solid rgb(255 255 255 / 8%);
}

.pagination-right :deep(.el-pagination button:hover) {
  color: #d8d0e4;
}

.pagination-right :deep(.el-pagination .btn-next),
.pagination-right :deep(.el-pagination .btn-prev) {
  background: #211c29;
  border: 1px solid rgb(255 255 255 / 8%);
}

.pagination-right :deep(.el-pagination .el-pager li) {
  background: #211c29;
  border: 1px solid rgb(255 255 255 / 8%);
}

.pagination-right :deep(.el-pagination .el-pager li.active) {
  background: rgba(103, 80, 164, 0.5);
  border-color: #6750a4;
  color: #fff;
}

:deep(.el-table) {
  background: #16121d;
}

:deep(.el-table th) {
  background: #211c29;
  color: #8e8798;
  border-bottom: 1px solid rgb(255 255 255 / 6%);
}

:deep(.el-table td) {
  color: #d8d0e4;
  border-bottom: 1px solid rgb(255 255 255 / 6%);
}

:deep(.el-table tr:hover td) {
  background: rgb(255 255 255 / 4%);
}

:deep(.el-table .el-checkbox__inner) {
  background: #211c29;
  border: 1px solid rgb(255 255 255 / 20%);
}

:deep(.el-table .el-checkbox__inner:hover) {
  border-color: #6750a4;
}

:deep(.el-table .el-checkbox__input.is-checked .el-checkbox__inner) {
  background: #6750a4;
  border-color: #6750a4;
}

:deep(.el-button--primary) {
  background: linear-gradient(135deg, #6750a4 0%, #6750a4 100%);
  border-color: #6750a4;
}

:deep(.el-button--default) {
  background: #211c29;
  border-color: rgb(255 255 255 / 8%);
  color: #d8d0e4;
}

:deep(.el-button--default:hover) {
  background: rgb(255 255 255 / 6%);
}

:deep(.el-button--danger) {
  background: rgba(248, 113, 113, 0.15);
  border-color: rgba(248, 113, 113, 0.3);
  color: #f87171;
}

:deep(.el-button--danger:hover) {
  background: rgba(248, 113, 113, 0.25);
}
</style>
