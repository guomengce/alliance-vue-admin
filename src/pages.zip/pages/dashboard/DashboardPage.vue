<script setup lang="ts">
import * as echarts from 'echarts'
import { nextTick, onBeforeUnmount, onMounted, ref } from 'vue'

type SummaryCard = {
  title: string
  icon: string
  tone: string
  main: string
  unit?: string
  meta?: string
  footer: string
  progress?: number
  rows?: { label: string; value: string }[]
}

type QuickLink = {
  title: string
  description: string
  icon: string
}

const orderTrendRef = ref<HTMLDivElement | null>(null)
const creditUsageRef = ref<HTMLDivElement | null>(null)
const priceTrendRef = ref<HTMLDivElement | null>(null)
let charts: echarts.ECharts[] = []

const summaryCards: SummaryCard[] = [
  {
    title: '总会员数',
    icon: 'ri-group-line',
    tone: 'violet',
    main: '2,410',
    meta: '● 实时',
    footer: '最后更新：14:32:30',
    rows: [
      { label: '今日新增', value: '42' },
      { label: 'KYC 通过率', value: '89.2%' },
    ],
  },
  {
    title: '今日订单量 / 认购总金额',
    icon: 'ri-file-list-3-line',
    tone: 'lavender',
    main: '156',
    unit: '¥ 89,200.00  USDT',
    footer: '最后更新：14:32:30',
  },
  {
    title: '今日佣金派发总额',
    icon: 'ri-coins-line',
    tone: 'gold',
    main: '¥ 15,800.00',
    unit: 'USDT',
    footer: '最后刷新：2023-11-23 04:00:00',
    meta: '每日 04:00 刷新前日数据',
  },
  {
    title: '排队锁定总额 (31%)',
    icon: 'ri-lock-line',
    tone: 'blue',
    main: '¥ 6,900.00',
    unit: 'USDT',
    footer: '最后更新：14:32:30',
    progress: 31,
  },
  {
    title: '公司余额',
    icon: 'ri-wallet-3-line',
    tone: 'green',
    main: '128,450.00',
    unit: 'USDT',
    footer: '最后更新：14:32:30',
    rows: [
      { label: 'TROO', value: '452,190.22' },
      { label: '≈ ¥', value: '1,240,975.68' },
    ],
  },
]

const quickLinks: QuickLink[] = [
  { title: '用户管理', description: '查看用户与KYC情况', icon: 'ri-user-3-line' },
  { title: '套餐管理', description: '管理认购套餐与配置', icon: 'ri-stack-line' },
  { title: '订单管理', description: '查看订单与认购记录', icon: 'ri-file-list-3-line' },
  { title: '佣金管理', description: '查看佣金与派发记录', icon: 'ri-percent-line' },
  { title: '排队账号管理', description: '管理排队账号与锁定', icon: 'ri-user-follow-line' },
  { title: '结算管理', description: '查看结算记录与状态', icon: 'ri-calendar-check-line' },
  { title: '财务管理', description: '资金流水与钱包管理', icon: 'ri-wallet-3-line' },
  { title: '数据报表', description: '查看各类统计报表', icon: 'ri-bar-chart-box-line' },
]

const chartTextStyle = {
  color: '#8e8798',
  fontFamily: 'var(--font-family-sans)',
}

const baseGrid = {
  top: 46,
  right: 26,
  bottom: 30,
  left: 44,
}

const mountCharts = () => {
  if (!orderTrendRef.value || !creditUsageRef.value || !priceTrendRef.value) return

  charts = [
    echarts.init(orderTrendRef.value),
    echarts.init(creditUsageRef.value),
    echarts.init(priceTrendRef.value),
  ]

  charts[0].setOption({
    color: ['#9f7aea', '#4174db'],
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(18, 15, 24, 0.94)',
      borderColor: 'rgba(143, 120, 216, 0.32)',
      textStyle: { color: '#f5f1ff' },
    },
    legend: {
      top: 5,
      right: 22,
      itemWidth: 12,
      itemHeight: 12,
      textStyle: chartTextStyle,
      data: ['订单量（笔）', '认购金额（USDT）'],
    },
    grid: baseGrid,
    xAxis: {
      type: 'category',
      data: ['11-18', '11-19', '11-20', '11-21', '11-22', '11-23', '11-24'],
      axisLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.12)' } },
      axisTick: { show: false },
      axisLabel: chartTextStyle,
    },
    yAxis: [
      {
        type: 'value',
        min: 0,
        max: 200,
        splitLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.08)' } },
        axisLabel: chartTextStyle,
      },
      {
        type: 'value',
        min: 0,
        max: 100,
        axisLabel: { ...chartTextStyle, formatter: '{value}K' },
        splitLine: { show: false },
      },
    ],
    series: [
      {
        name: '订单量（笔）',
        type: 'bar',
        barWidth: 22,
        data: [98, 69, 158, 99, 58, 81, 146],
        itemStyle: {
          borderRadius: [5, 5, 0, 0],
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: '#b58cff' },
            { offset: 1, color: '#6750a4' },
          ]),
        },
      },
      {
        name: '认购金额（USDT）',
        type: 'line',
        yAxisIndex: 1,
        smooth: true,
        symbol: 'circle',
        symbolSize: 11,
        data: [58, 49, 82, 61, 45, 49, 74],
        lineStyle: { width: 3, color: '#4d83f1' },
        itemStyle: { color: '#4d83f1', borderColor: '#6ea1ff', borderWidth: 2 },
      },
    ],
  } satisfies echarts.EChartsOption)

  charts[1].setOption({
    series: [
      {
        type: 'pie',
        radius: ['64%', '82%'],
        center: ['50%', '50%'],
        startAngle: 94,
        silent: true,
        label: { show: false },
        data: [
          {
            value: 95,
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
                { offset: 0, color: '#c7a8ff' },
                { offset: 1, color: '#6750a4' },
              ]),
            },
          },
          { value: 5, itemStyle: { color: 'rgba(255, 255, 255, 0.08)' } },
        ],
      },
    ],
  } satisfies echarts.EChartsOption)

  charts[2].setOption({
    color: ['#b58cff'],
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(18, 15, 24, 0.94)',
      borderColor: 'rgba(143, 120, 216, 0.32)',
      textStyle: { color: '#f5f1ff' },
    },
    grid: { top: 18, right: 14, bottom: 28, left: 42 },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00', '24:00'],
      axisLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.12)' } },
      axisTick: { show: false },
      axisLabel: chartTextStyle,
    },
    yAxis: {
      type: 'value',
      min: 0.7,
      max: 0.9,
      splitLine: { lineStyle: { color: 'rgba(255, 255, 255, 0.08)' } },
      axisLabel: chartTextStyle,
    },
    series: [
      {
        type: 'line',
        smooth: true,
        showSymbol: false,
        lineStyle: { width: 2, color: '#b58cff' },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: 'rgba(181, 140, 255, 0.34)' },
            { offset: 1, color: 'rgba(103, 80, 164, 0.02)' },
          ]),
        },
        data: [0.735, 0.759, 0.764, 0.824, 0.858, 0.805, 0.862],
      },
    ],
  } satisfies echarts.EChartsOption)
}

const resizeCharts = () => charts.forEach(chart => chart.resize())

onMounted(async () => {
  await nextTick()
  mountCharts()
  window.addEventListener('resize', resizeCharts)
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', resizeCharts)
  charts.forEach(chart => chart.dispose())
  charts = []
})
</script>

<template>
  <section class="dashboard-page">
    <div class="summary-grid">
      <article
        v-for="card in summaryCards"
        :key="card.title"
        class="panel summary-card"
      >
        <div class="summary-head">
          <span class="metric-icon" :class="`is-${card.tone}`">
            <i :class="card.icon" aria-hidden="true"></i>
          </span>
          <div>
            <h2>{{ card.title }}</h2>
            <span v-if="card.meta" class="metric-meta">{{ card.meta }}</span>
          </div>
        </div>

        <strong class="metric-value">{{ card.main }}</strong>
        <span v-if="card.unit" class="metric-unit">{{ card.unit }}</span>

        <div v-if="card.progress" class="lock-progress">
          <span :style="{ width: `${card.progress}%` }"></span>
        </div>

        <div v-if="card.rows" class="metric-rows">
          <div v-for="row in card.rows" :key="row.label">
            <span>{{ row.label }}</span>
            <strong>{{ row.value }}</strong>
          </div>
        </div>

        <footer>
          <span>{{ card.footer }}</span>
          <button class="refresh-button" type="button" aria-label="刷新">
            <i class="ri-refresh-line" aria-hidden="true"></i>
          </button>
        </footer>
      </article>
    </div>

    <div class="analytics-grid">
      <article class="panel trend-panel">
        <header class="panel-header">
          <div>
            <h2>认购订单量与认购金额趋势</h2>
            <span>ⓘ</span>
          </div>
          <select aria-label="统计维度">
            <option>全部套餐</option>
            <option>基础套餐</option>
            <option>高级套餐</option>
          </select>
        </header>
        <div class="tabs">
          <button type="button" class="is-active">日</button>
          <button type="button">周</button>
          <button type="button">月</button>
        </div>
        <div ref="orderTrendRef" class="chart chart-large"></div>
      </article>

      <article class="panel usage-panel">
        <header class="panel-header">
          <h2>信用额度池使用率（今日）</h2>
        </header>
        <div class="usage-body">
          <div class="donut-wrap">
            <div ref="creditUsageRef" class="chart donut-chart"></div>
            <div class="donut-center">
              <strong>95%</strong>
              <span>已使用</span>
            </div>
          </div>
          <div class="usage-stats">
            <span>总额度</span>
            <strong>¥ 40,000.00</strong>
            <small>USDT</small>
            <span>剩余额度</span>
            <strong>¥ 2,000.00</strong>
            <small>USDT</small>
          </div>
        </div>
        <button class="detail-button" type="button">查看详细</button>
      </article>

      <article class="panel price-panel">
        <header class="panel-header">
          <div>
            <h2>TROO 实时市价</h2>
            <small>(Yahoo Finance)</small>
            <span>ⓘ</span>
          </div>
          <span class="update-time">更新于：14:32:30　↻</span>
        </header>
        <div class="price-main">
          <strong>0.8421</strong>
          <span>USDT</span>
          <em>+0.0421 (+5.26%) ↑</em>
        </div>
        <div ref="priceTrendRef" class="chart price-chart"></div>
        <div class="range-tabs">
          <button type="button" class="is-active">1D</button>
          <button type="button">1W</button>
          <button type="button">1M</button>
          <button type="button">3M</button>
          <button type="button">1Y</button>
        </div>
      </article>
    </div>

    <article class="panel quick-panel">
      <h2>快捷跳转</h2>
      <div class="quick-grid">
        <button
          v-for="link in quickLinks"
          :key="link.title"
          type="button"
          class="quick-card"
        >
          <i :class="link.icon" aria-hidden="true"></i>
          <strong>{{ link.title }}</strong>
          <small>{{ link.description }}</small>
        </button>
      </div>
    </article>
  </section>
</template>

<style scoped>
.dashboard-page {
  display: grid;
  gap: 20px;
  color: #f6f2ff;
}

.panel {
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background:
    linear-gradient(180deg, rgb(255 255 255 / 3.5%), rgb(255 255 255 / 1.2%)),
    #16121d;
  box-shadow: inset 0 1px 0 rgb(255 255 255 / 4%), 0 18px 50px rgb(0 0 0 / 26%);
}

.summary-grid {
  display: grid;
  grid-template-columns: repeat(5, minmax(180px, 1fr));
  gap: 16px;
}

.summary-card {
  min-height: 214px;
  display: flex;
  flex-direction: column;
  padding: 22px;
}

.summary-head,
.panel-header,
.metric-rows,
.usage-body,
.price-main,
.range-tabs,
.tabs {
  display: flex;
  align-items: center;
}

.summary-head {
  justify-content: space-between;
  gap: 14px;
  margin-bottom: 18px;
}

.summary-head > div {
  flex: 1;
  min-width: 0;
}

.summary-head h2,
.panel-header h2,
.quick-panel h2 {
  margin: 0;
  color: #f6f2ff;
  font-size: 15px;
  font-weight: 800;
}

.metric-icon {
  display: grid;
  width: 38px;
  height: 38px;
  flex: 0 0 auto;
  place-items: center;
  border-radius: 8px;
  color: #d8c8ff;
  background: rgb(103 80 164 / 22%);
  font-size: 18px;
}

.metric-icon.is-gold {
  color: #ffc857;
  background: rgb(255 200 87 / 12%);
}

.metric-icon.is-blue {
  color: #62a8ff;
  background: rgb(69 132 242 / 14%);
}

.metric-icon.is-green {
  color: #20d898;
  background: rgb(32 216 152 / 12%);
}

.metric-meta {
  display: block;
  margin-top: 6px;
  color: #20e58b;
  font-size: 12px;
}

.metric-value {
  display: block;
  color: #fff;
  font-family: var(--font-family-mono);
  font-size: clamp(24px, 2vw, 30px);
  line-height: 1.15;
  letter-spacing: 0;
}

.metric-unit {
  display: block;
  margin-top: 12px;
  color: #aaa3b6;
  font-family: var(--font-family-mono);
  font-size: 13px;
  white-space: pre-line;
}

.metric-rows {
  justify-content: space-between;
  gap: 12px;
  margin-top: auto;
  padding-top: 18px;
}

.metric-rows div {
  display: grid;
  gap: 8px;
}

.metric-rows span,
.summary-card footer,
.usage-stats span,
.usage-stats small,
.panel-header small,
.update-time {
  color: #8e8798;
  font-size: 12px;
}

.metric-rows strong {
  color: #f7f2ff;
  font-family: var(--font-family-mono);
  font-size: 18px;
}

.lock-progress {
  height: 8px;
  margin-top: auto;
  overflow: hidden;
  border-radius: 999px;
  background: rgb(255 255 255 / 10%);
}

.lock-progress span {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: linear-gradient(90deg, #d8c8ff, #9b7df1);
}

.summary-card footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 22px;
  padding-top: 16px;
  border-top: 1px solid rgb(255 255 255 / 6%);
}

.refresh-button {
  color: #a99ec0;
  font-size: 20px;
}

.analytics-grid {
  display: grid;
  grid-template-columns: minmax(420px, 1.25fr) minmax(260px, 0.72fr) minmax(390px, 1.2fr);
  gap: 16px;
}

.trend-panel,
.usage-panel,
.price-panel {
  padding: 22px;
}

.panel-header {
  justify-content: space-between;
  gap: 16px;
  min-height: 30px;
}

.panel-header > div {
  display: flex;
  align-items: baseline;
  gap: 6px;
}

.panel-header select {
  min-width: 104px;
  height: 34px;
  padding: 0 12px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  color: #f2ecff;
  background: #211c29;
  font-size: 12px;
}

.tabs {
  gap: 18px;
  margin: 10px 0 2px;
}

.tabs button,
.range-tabs button {
  min-width: 42px;
  height: 28px;
  border-radius: 8px;
  color: #aaa3b6;
  font-size: 12px;
  font-weight: 800;
}

.tabs button.is-active,
.range-tabs button.is-active {
  color: #fff;
  background: rgb(103 80 164 / 55%);
}

.chart {
  width: 100%;
}

.chart-large {
  height: 238px;
}

.usage-body {
  align-items: stretch;
  gap: 20px;
  margin-top: 22px;
}

.donut-wrap {
  position: relative;
  width: 170px;
  flex: 0 0 170px;
  aspect-ratio: 1;
}

.donut-chart {
  height: 170px;
}

.donut-center {
  position: absolute;
  inset: 0;
  display: grid;
  place-content: center;
  text-align: center;
  pointer-events: none;
}

.donut-center strong {
  color: #efe8ff;
  font-size: 34px;
  line-height: 1;
}

.donut-center span {
  margin-top: 8px;
  color: #aaa3b6;
  font-size: 13px;
}

.usage-stats {
  display: grid;
  align-content: center;
  gap: 8px;
  min-width: 0;
}

.usage-stats strong {
  color: #fff;
  font-family: var(--font-family-mono);
  font-size: 16px;
}

.detail-button {
  width: 100%;
  height: 44px;
  margin-top: 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  color: #d6c7ff;
  background: linear-gradient(180deg, rgb(255 255 255 / 8%), rgb(255 255 255 / 3%));
  font-weight: 800;
}

.price-main {
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 10px;
}

.price-main strong {
  color: #fff;
  font-family: var(--font-family-mono);
  font-size: 34px;
}

.price-main span {
  color: #aaa3b6;
  font-family: var(--font-family-mono);
}

.price-main em {
  width: 100%;
  color: #1fe98e;
  font-style: normal;
  font-weight: 800;
}

.price-chart {
  height: 185px;
  margin-top: 10px;
}

.range-tabs {
  gap: 20px;
  margin-top: 6px;
}

.quick-panel {
  padding: 24px;
}

.quick-grid {
  display: grid;
  grid-template-columns: repeat(8, minmax(110px, 1fr));
  gap: 14px;
  margin-top: 18px;
}

.quick-card {
  display: grid;
  min-height: 132px;
  justify-items: center;
  align-content: center;
  gap: 9px;
  padding: 16px 10px;
  border: 1px solid rgb(255 255 255 / 6%);
  border-radius: 8px;
  color: #f5efff;
  background: rgb(255 255 255 / 3.5%);
  transition:
    transform 0.18s ease,
    border-color 0.18s ease,
    background 0.18s ease;
}

.quick-card:hover {
  transform: translateY(-2px);
  border-color: rgb(181 140 255 / 48%);
  background: rgb(103 80 164 / 18%);
}

.quick-card i {
  color: #b58cff;
  font-size: 25px;
  line-height: 1;
}

.quick-card strong {
  font-size: 15px;
}

.quick-card small {
  color: #8e8798;
  font-size: 12px;
}

@media (width <= 1420px) {
  .summary-grid {
    grid-template-columns: repeat(3, minmax(220px, 1fr));
  }

  .analytics-grid {
    grid-template-columns: 1fr 1fr;
  }

  .trend-panel,
  .price-panel {
    grid-column: span 2;
  }

  .quick-grid {
    grid-template-columns: repeat(4, minmax(140px, 1fr));
  }
}

@media (width <= 820px) {
  .summary-grid,
  .analytics-grid,
  .quick-grid {
    grid-template-columns: 1fr;
  }

  .trend-panel,
  .price-panel {
    grid-column: auto;
  }

  .usage-body {
    flex-direction: column;
    align-items: center;
  }

  .panel-header {
    align-items: flex-start;
    flex-direction: column;
  }
}
</style>
