<script setup lang="ts">
import { ref, computed } from 'vue'

interface SettlementLog {
  id: string
  batch: string
  date: string
  status: 'pending' | 'processing' | 'completed' | 'failed'
  count: number
  totalAmount: number
  successCount: number
  failedCount: number
  startTime: string
  endTime?: string
  errorMessage?: string
}

interface ExceptionItem {
  id: string
  user: string
  orderId: string
  amount: number
  type: 'withdraw' | 'commission' | 'bonus'
  error: string
  status: 'pending' | 'retry' | 'resolved'
  createdAt: string
}

const settlementStats = ref({
  todayProcessed: 1568,
  todayAmount: 2450000,
  successRate: 99.2,
  pendingCount: 23,
})

const logs = ref<SettlementLog[]>([
  { 
    id: 'SET001', 
    batch: 'D+1-20240528', 
    date: '2024-05-28', 
    status: 'completed', 
    count: 512, 
    totalAmount: 850000, 
    successCount: 510, 
    failedCount: 2, 
    startTime: '00:00:05',
    endTime: '00:15:32'
  },
  { 
    id: 'SET002', 
    batch: 'D+1-20240527', 
    date: '2024-05-27', 
    status: 'completed', 
    count: 489, 
    totalAmount: 780000, 
    successCount: 489, 
    failedCount: 0, 
    startTime: '00:00:03',
    endTime: '00:12:18'
  },
  { 
    id: 'SET003', 
    batch: 'D+1-20240526', 
    date: '2024-05-26', 
    status: 'completed', 
    count: 567, 
    totalAmount: 820000, 
    successCount: 565, 
    failedCount: 2, 
    startTime: '00:00:08',
    endTime: '00:18:45'
  },
  { 
    id: 'SET004', 
    batch: 'D+1-20240525', 
    date: '2024-05-25', 
    status: 'failed', 
    count: 523, 
    totalAmount: 790000, 
    successCount: 480, 
    failedCount: 43, 
    startTime: '00:00:02',
    errorMessage: '银行接口超时'
  },
])

const exceptions = ref<ExceptionItem[]>([
  { id: 'EXC001', user: '张三', orderId: 'ORD20240528001', amount: 1200, type: 'commission', error: '账户余额不足', status: 'pending', createdAt: '2024-05-28 10:30:00' },
  { id: 'EXC002', user: '李四', orderId: 'ORD20240528002', amount: 5000, type: 'withdraw', error: '银行卡信息错误', status: 'retry', createdAt: '2024-05-28 09:15:00' },
  { id: 'EXC003', user: '王五', orderId: 'ORD20240528003', amount: 800, type: 'bonus', error: '风控审核未通过', status: 'pending', createdAt: '2024-05-28 11:20:00' },
])

const searchQuery = ref('')

const filteredLogs = computed(() => {
  return logs.value.filter(log => 
    log.id.includes(searchQuery.value) || 
    log.batch.includes(searchQuery.value)
  )
})

const statusColors: Record<string, string> = {
  pending: '#60a5fa',
  processing: '#fbbf24',
  completed: '#14b8a6',
  failed: '#f87171',
}

const statusLabels: Record<string, string> = {
  pending: '待执行',
  processing: '执行中',
  completed: '已完成',
  failed: '失败',
}

const typeLabels: Record<string, string> = {
  withdraw: '提现',
  commission: '佣金',
  bonus: '奖金',
}

const triggerSettlement = () => {
  alert('手动结算已触发，正在处理中...')
}

const retryException = (item: ExceptionItem) => {
  item.status = 'retry'
}

const resolveException = (item: ExceptionItem) => {
  item.status = 'resolved'
}
</script>

<template>
  <div class="settlements-page">
    <!-- Header -->
    <div class="page-header">
      <div class="header-left">
        <h2>结算管理</h2>
        <p>D+1执行监控日志、手动结算触发器、异常处理</p>
      </div>
      <div class="header-actions">
        <button class="btn-primary" @click="triggerSettlement">
          <i class="ri-rocket-line" aria-hidden="true"></i>
          手动结算
        </button>
      </div>
    </div>

    <!-- Stats Cards -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon"><i class="ri-file-list-3-line" aria-hidden="true"></i></div>
        <div class="stat-info">
          <p class="stat-title">今日处理笔数</p>
          <h3 class="stat-value">{{ settlementStats.todayProcessed }}</h3>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon"><i class="ri-coins-line" aria-hidden="true"></i></div>
        <div class="stat-info">
          <p class="stat-title">今日结算金额</p>
          <h3 class="stat-value">${{ settlementStats.todayAmount.toLocaleString() }}</h3>
        </div>
      </div>
      <div class="stat-card success">
        <div class="stat-icon"><i class="ri-check-line" aria-hidden="true"></i></div>
        <div class="stat-info">
          <p class="stat-title">成功率</p>
          <h3 class="stat-value">{{ settlementStats.successRate }}%</h3>
        </div>
      </div>
      <div class="stat-card warning">
        <div class="stat-icon"><i class="ri-alert-line" aria-hidden="true"></i></div>
        <div class="stat-info">
          <p class="stat-title">待处理异常</p>
          <h3 class="stat-value">{{ settlementStats.pendingCount }}</h3>
        </div>
      </div>
    </div>

    <!-- Tabs -->
    <div class="tabs">
      <button 
        class="tab-btn active"
      >
        结算日志
      </button>
      <button 
        class="tab-btn"
      >
        异常处理
        <span class="tab-badge">{{ exceptions.filter(e => e.status !== 'resolved').length }}</span>
      </button>
    </div>

    <!-- Settlement Logs -->
    <div class="table-container">
      <div class="table-header">
      <div class="search-box">
        <i class="ri-search-line" aria-hidden="true"></i>
          <input 
            v-model="searchQuery" 
            type="text" 
            placeholder="搜索结算ID、批次号..."
          />
        </div>
      </div>

      <table class="logs-table">
        <thead>
          <tr>
            <th>结算ID</th>
            <th>批次号</th>
            <th>日期</th>
            <th>总笔数</th>
            <th>总金额</th>
            <th>成功/失败</th>
            <th>状态</th>
            <th>执行时间</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="log in filteredLogs" :key="log.id">
            <td><code>{{ log.id }}</code></td>
            <td><code>{{ log.batch }}</code></td>
            <td>{{ log.date }}</td>
            <td>{{ log.count }}</td>
            <td>${{ log.totalAmount.toLocaleString() }}</td>
            <td>
              <span class="success-count">{{ log.successCount }}</span>
              <span class="separator">/</span>
              <span class="failed-count">{{ log.failedCount }}</span>
            </td>
            <td>
              <span 
                class="status-tag" 
                :style="{ backgroundColor: statusColors[log.status] + '20', color: statusColors[log.status] }"
              >
                {{ statusLabels[log.status] }}
              </span>
            </td>
            <td>
              <span>{{ log.startTime }}</span>
              <span v-if="log.endTime"> - {{ log.endTime }}</span>
            </td>
          </tr>
        </tbody>
      </table>

      <div v-if="filteredLogs.length === 0" class="empty-state">
        <i class="ri-inbox-line" aria-hidden="true"></i>
        <p>没有找到匹配的结算日志</p>
      </div>
    </div>

    <!-- Exceptions Section -->
    <div class="exceptions-section">
      <h3>异常处理</h3>
      <div class="exceptions-list">
        <div 
          v-for="item in exceptions" 
          :key="item.id" 
          class="exception-card"
          :class="{ 'is-resolved': item.status === 'resolved' }"
        >
          <div class="exception-header">
            <div class="exception-info">
              <code>{{ item.id }}</code>
              <span class="user-name">{{ item.user }}</span>
            </div>
            <span 
              class="status-badge" 
              :class="item.status"
            >
              {{ item.status === 'pending' ? '待处理' : item.status === 'retry' ? '重试中' : '已解决' }}
            </span>
          </div>

          <div class="exception-details">
            <div>
              <span class="detail-label">订单号</span>
              <code>{{ item.orderId }}</code>
            </div>
            <div>
              <span class="detail-label">类型</span>
              <span class="type-tag">{{ typeLabels[item.type] }}</span>
            </div>
            <div>
              <span class="detail-label">金额</span>
              <span class="amount">${{ item.amount.toLocaleString() }}</span>
            </div>
          </div>

          <div class="error-section">
            <span class="error-label">错误原因</span>
            <span class="error-message">{{ item.error }}</span>
          </div>

          <div class="exception-footer">
            <span class="created-at">{{ item.createdAt }}</span>
            <div class="exception-actions">
              <button 
                v-if="item.status !== 'resolved'" 
                class="action-btn" 
                @click="retryException(item)"
              >
                🔄 重试
              </button>
              <button 
                v-if="item.status !== 'resolved'" 
                class="action-btn primary" 
                @click="resolveException(item)"
              >
                <i class="ri-check-line" aria-hidden="true"></i>
                标记已解决
              </button>
            </div>
          </div>
        </div>

        <div v-if="exceptions.length === 0" class="empty-state">
          <i class="ri-check-line" aria-hidden="true"></i>
          <p>暂无异常记录</p>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.settlements-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 100%;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.header-left h2 {
  margin: 0 0 6px;
  color: #fff;
  font-size: 24px;
  font-weight: 700;
}

.header-left p {
  margin: 0;
  color: #8e8798;
  font-size: 14px;
}

.btn-primary {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  border: none;
  border-radius: 8px;
  background: linear-gradient(135deg, #6750a4 0%, #6750a4 100%);
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 24px rgb(103 80 164 / 30%);
}

/* Stats */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
}

.stat-card.success {
  border-color: rgba(20, 184, 166, 0.3);
  background: rgba(20, 184, 166, 0.08);
}

.stat-card.warning {
  border-color: rgba(251, 191, 36, 0.3);
  background: rgba(251, 191, 36, 0.08);
}

.stat-icon {
  display: flex;
  width: 48px;
  height: 48px;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  background: rgba(103, 80, 164, 0.2);
  color: #c4b5fd;
  font-size: 24px;
}

.stat-card.success .stat-icon {
  background: rgba(20, 184, 166, 0.2);
  color: #14b8a6;
}

.stat-card.warning .stat-icon {
  background: rgba(251, 191, 36, 0.2);
  color: #fbbf24;
}

.stat-info {
  flex: 1;
}

.stat-title {
  margin: 0;
  color: #8e8798;
  font-size: 13px;
}

.stat-value {
  margin: 4px 0 0;
  color: #fff;
  font-size: 24px;
  font-weight: 700;
}

/* Tabs */
.tabs {
  display: flex;
  gap: 8px;
}

.tab-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 24px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  color: #8e8798;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.tab-btn.active {
  border-color: #6750a4;
  background: rgba(103, 80, 164, 0.2);
  color: #c4b5fd;
}

.tab-badge {
  padding: 2px 8px;
  border-radius: 10px;
  background: rgba(248, 113, 113, 0.2);
  color: #f87171;
  font-size: 12px;
}

/* Table */
.table-container {
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  box-shadow: 0 18px 50px rgb(0 0 0 / 26%);
  overflow: hidden;
}

.table-header {
  display: flex;
  justify-content: flex-end;
  padding: 16px 20px;
  border-bottom: 1px solid rgb(255 255 255 / 6%);
}

.search-box {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
}

.search-box i {
  color: #b58cff;
  font-size: 14px;
}

.search-box input {
  border: none;
  background: transparent;
  color: #f6f2ff;
  font-size: 14px;
  outline: none;
  width: 200px;
}

.search-box input::placeholder {
  color: #777181;
}

.logs-table {
  width: 100%;
  border-collapse: collapse;
}

.logs-table th {
  padding: 16px;
  text-align: left;
  background: #211c29;
  color: #8e8798;
  font-size: 13px;
  font-weight: 600;
}

.logs-table td {
  padding: 16px;
  border-bottom: 1px solid rgb(255 255 255 / 6%);
  color: #d8d0e4;
}

.logs-table tr:hover td {
  background: rgb(255 255 255 / 4%);
}

.logs-table td code {
  padding: 4px 8px;
  border-radius: 4px;
  background: #211c29;
  color: #b58cff;
  font-family: monospace;
  font-size: 12px;
}

.success-count {
  color: #14b8a6;
  font-weight: 600;
}

.failed-count {
  color: #f87171;
  font-weight: 600;
}

.separator {
  margin: 0 4px;
  color: #8e8798;
}

.status-tag {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

/* Empty State */
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 48px;
  color: #8e8798;
}

.empty-state i {
  font-size: 48px;
  margin-bottom: 12px;
}

/* Exceptions */
.exceptions-section {
  margin-top: 20px;
}

.exceptions-section h3 {
  margin: 0 0 16px;
  color: #fff;
  font-size: 18px;
  font-weight: 600;
}

.exceptions-list {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}

.exception-card {
  padding: 20px;
  border: 1px solid rgba(248, 113, 113, 0.3);
  border-radius: 8px;
  background: #16121d;
}

.exception-card.is-resolved {
  border-color: rgba(20, 184, 166, 0.3);
  opacity: 0.8;
}

.exception-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.exception-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.exception-info code {
  padding: 4px 8px;
  border-radius: 4px;
  background: #211c29;
  color: #b58cff;
  font-family: monospace;
  font-size: 12px;
}

.user-name {
  font-weight: 600;
  color: #f6f2ff;
}

.status-badge {
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

.status-badge.pending {
  background: rgba(248, 113, 113, 0.2);
  color: #f87171;
}

.status-badge.retry {
  background: rgba(251, 191, 36, 0.2);
  color: #fbbf24;
}

.status-badge.resolved {
  background: rgba(20, 184, 166, 0.2);
  color: #14b8a6;
}

.exception-details {
  display: flex;
  gap: 16px;
  margin-bottom: 12px;
}

.detail-label {
  color: #8e8798;
  font-size: 12px;
}

.exception-details code {
  padding: 2px 6px;
  border-radius: 4px;
  background: #211c29;
  color: #b58cff;
  font-family: monospace;
  font-size: 12px;
}

.type-tag {
  padding: 2px 8px;
  border-radius: 4px;
  background: rgba(103, 80, 164, 0.2);
  color: #c4b5fd;
  font-size: 12px;
}

.amount {
  color: #c4b5fd;
  font-weight: 600;
}

.error-section {
  padding: 12px;
  border-radius: 8px;
  background: rgba(248, 113, 113, 0.1);
  margin-bottom: 12px;
}

.error-label {
  display: block;
  margin-bottom: 4px;
  color: #f87171;
  font-size: 12px;
  font-weight: 600;
}

.error-message {
  color: #fca5a5;
  font-size: 13px;
}

.exception-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.created-at {
  color: #8e8798;
  font-size: 12px;
}

.exception-actions {
  display: flex;
  gap: 8px;
}

.action-btn {
  padding: 6px 12px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 6px;
  background: #211c29;
  color: #d8d0e4;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.action-btn:hover {
  background: rgb(103 80 164 / 18%);
}

.action-btn.primary {
  border-color: #6750a4;
  color: #c4b5fd;
}

.action-btn.primary:hover {
  background: rgba(103, 80, 164, 0.2);
}

/* Responsive */
@media (max-width: 1200px) {
  .exceptions-list {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 900px) {
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }

  .logs-table {
    display: block;
    overflow-x: auto;
  }

  .exceptions-list {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 640px) {
  .stats-grid {
    grid-template-columns: 1fr;
  }

  .exception-details {
    flex-direction: column;
    gap: 8px;
  }
}
</style>