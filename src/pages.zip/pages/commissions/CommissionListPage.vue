<script setup lang="ts">
import { ref, computed } from 'vue'

interface CommissionRecord {
  id: string
  user: string
  level: string
  amount: number
  type: 'earned' | 'distributed' | 'overflow'
  status: 'pending' | 'completed' | 'failed'
  date: string
  orderId?: string
}

const creditPool = ref({
  total: 1250000,
  available: 890000,
  locked: 360000,
  todayDistributed: 45000,
  todayOverflow: 12000,
})

const records = ref<CommissionRecord[]>([
  { id: 'COM001', user: '张三', level: 'L3', amount: 1200, type: 'earned', status: 'completed', date: '2024-05-28 10:30:00', orderId: 'ORD20240528001' },
  { id: 'COM002', user: '李四', level: 'L5', amount: 5000, type: 'distributed', status: 'completed', date: '2024-05-28 09:15:00' },
  { id: 'COM003', user: '王五', level: 'L2', amount: 800, type: 'earned', status: 'pending', date: '2024-05-28 11:20:00' },
  { id: 'COM004', user: '赵六', level: 'L4', amount: 2500, type: 'distributed', status: 'completed', date: '2024-05-27 16:45:00' },
  { id: 'COM005', user: '孙七', level: 'L3', amount: 3200, type: 'overflow', status: 'completed', date: '2024-05-27 14:30:00' },
  { id: 'COM006', user: '周八', level: 'L1', amount: 300, type: 'earned', status: 'pending', date: '2024-05-28 08:00:00' },
])

const searchQuery = ref('')
const typeFilter = ref('all')

const filteredRecords = computed(() => {
  return records.value.filter(record => {
    const matchesSearch = record.id.includes(searchQuery.value) || 
                         record.user.includes(searchQuery.value)
    const matchesType = typeFilter.value === 'all' || record.type === typeFilter.value
    return matchesSearch && matchesType
  })
})

const typeColors: Record<string, string> = {
  earned: '#14b8a6',
  distributed: '#60a5fa',
  overflow: '#f87171',
}

const typeLabels: Record<string, string> = {
  earned: '赚取',
  distributed: '派发',
  overflow: '溢出',
}

const statusLabels: Record<string, string> = {
  pending: '待处理',
  completed: '已完成',
  failed: '失败',
}

const triggerDistribution = () => {
  alert('手动派发已触发，正在处理中...')
}

const viewOverflowDetails = () => {
  alert('查看溢出详情')
}
</script>

<template>
  <div class="commissions-page">
    <!-- Header -->
    <div class="page-header">
      <div class="header-left">
        <h2>佣金管理</h2>
        <p>信用池监控大盘、派发与溢出追溯列表</p>
      </div>
      <div class="header-actions">
        <button class="btn-secondary" @click="viewOverflowDetails">
          <i class="ri-bar-chart-box-line" aria-hidden="true"></i>
          溢出追溯
        </button>
        <button class="btn-primary" @click="triggerDistribution">
          <i class="ri-rocket-line" aria-hidden="true"></i>
          手动派发
        </button>
      </div>
    </div>

    <!-- Credit Pool Cards -->
    <div class="pool-cards">
      <div class="pool-card main">
        <div class="pool-header">
          <h3>信用池总览</h3>
          <span class="live-badge">LIVE</span>
        </div>
        <div class="pool-total">
          <span class="currency">$</span>
          <span class="amount">{{ creditPool.total.toLocaleString() }}</span>
        </div>
        <div class="pool-details">
          <div>
            <span class="label">可用余额</span>
            <span class="value success">${{ creditPool.available.toLocaleString() }}</span>
          </div>
          <div>
            <span class="label">锁定金额</span>
            <span class="value warning">${{ creditPool.locked.toLocaleString() }}</span>
          </div>
        </div>
        <div class="pool-progress">
          <div class="progress-bar">
            <div 
              class="progress-fill" 
              :style="{ width: (creditPool.available / creditPool.total * 100) + '%' }"
            ></div>
          </div>
          <span>{{ (creditPool.available / creditPool.total * 100).toFixed(1) }}% 可用</span>
        </div>
      </div>

      <div class="pool-card">
        <div class="mini-stat">
          <span class="mini-label">今日派发</span>
          <span class="mini-value">${{ creditPool.todayDistributed.toLocaleString() }}</span>
        </div>
      </div>

      <div class="pool-card warning">
        <div class="mini-stat">
          <span class="mini-label">今日溢出</span>
          <span class="mini-value">${{ creditPool.todayOverflow.toLocaleString() }}</span>
        </div>
      </div>
    </div>

    <!-- Filters -->
    <div class="filters-bar">
      <div class="search-box">
        <i class="ri-search-line" aria-hidden="true"></i>
        <input 
          v-model="searchQuery" 
          type="text" 
          placeholder="搜索记录ID、用户..."
        />
      </div>
      <div class="filter-group">
        <select v-model="typeFilter">
          <option value="all">全部类型</option>
          <option value="earned">赚取</option>
          <option value="distributed">派发</option>
          <option value="overflow">溢出</option>
        </select>
      </div>
    </div>

    <!-- Records Table -->
    <div class="table-container">
      <table class="records-table">
        <thead>
          <tr>
            <th>记录ID</th>
            <th>用户</th>
            <th>等级</th>
            <th>金额</th>
            <th>类型</th>
            <th>状态</th>
            <th>关联订单</th>
            <th>时间</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="record in filteredRecords" :key="record.id">
            <td><code>{{ record.id }}</code></td>
            <td>{{ record.user }}</td>
            <td>
              <span class="level-badge">{{ record.level }}</span>
            </td>
            <td class="text-right">
              <strong 
                :class="{ 
                  'text-success': record.type === 'earned',
                  'text-primary': record.type === 'distributed',
                  'text-danger': record.type === 'overflow'
                }"
              >
                {{ record.type === 'overflow' ? '-' : '+' }}${{ record.amount.toLocaleString() }}
              </strong>
            </td>
            <td>
              <span 
                class="type-tag" 
                :style="{ backgroundColor: typeColors[record.type] + '20', color: typeColors[record.type] }"
              >
                {{ typeLabels[record.type] }}
              </span>
            </td>
            <td>
              <span 
                class="status-tag" 
                :class="record.status"
              >
                {{ statusLabels[record.status] }}
              </span>
            </td>
            <td>
              <code v-if="record.orderId">{{ record.orderId }}</code>
              <span v-else class="empty">-</span>
            </td>
            <td>{{ record.date }}</td>
          </tr>
        </tbody>
      </table>

      <div v-if="filteredRecords.length === 0" class="empty-state">
        <i class="ri-inbox-line" aria-hidden="true"></i>
        <p>没有找到匹配的记录</p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.commissions-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 100%;
  color: #f6f2ff;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.header-left h2 {
  margin: 0 0 6px;
  color: #fff;
  font-size: 24px;
  font-weight: 700;
}

.header-left p {
  margin: 0;
  color: #8e8798;
  font-size: 14px;
}

.btn-primary {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  border: none;
  border-radius: 8px;
  background: linear-gradient(135deg, #6750a4 0%, #6750a4 100%);
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 24px rgb(103 80 164 / 30%);
}

.btn-secondary {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #d8d0e4;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-secondary:hover {
  background: rgb(103 80 164 / 18%);
  color: #fff;
}

/* Pool Cards */
.pool-cards {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  gap: 16px;
}

.pool-card {
  padding: 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
}

.pool-card.main {
  background: linear-gradient(135deg, #1e1829 0%, #16121d 100%);
  color: #f6f2ff;
}

.pool-card.warning {
  border-color: rgba(251, 191, 36, 0.3);
  background: rgba(251, 191, 36, 0.08);
}

.pool-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;
}

.pool-header h3 {
  margin: 0;
  color: #aaa3b6;
  font-size: 14px;
}

.live-badge {
  padding: 4px 10px;
  border-radius: 4px;
  background: #14b8a6;
  color: #fff;
  font-size: 10px;
  font-weight: 600;
}

.pool-total {
  display: flex;
  align-items: baseline;
  gap: 4px;
  margin-bottom: 16px;
}

.currency {
  color: #aaa3b6;
  font-size: 20px;
}

.pool-total .amount {
  color: #fff;
  font-size: 40px;
  font-weight: 700;
}

.pool-details {
  display: flex;
  gap: 24px;
  margin-bottom: 16px;
}

.pool-details div {
  display: flex;
  flex-direction: column;
}

.pool-details .label {
  color: #8e8798;
  font-size: 12px;
}

.pool-details .value {
  margin-top: 4px;
  font-size: 18px;
  font-weight: 600;
}

.pool-details .value.success {
  color: #14b8a6;
}

.pool-details .value.warning {
  color: #fbbf24;
}

.pool-progress {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.progress-bar {
  height: 8px;
  border-radius: 4px;
  background: rgba(255, 255, 255, 0.1);
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  border-radius: 4px;
  background: linear-gradient(90deg, #14b8a6, #0d766e);
}

.pool-progress span {
  color: #8e8798;
  font-size: 12px;
}

.mini-stat {
  display: flex;
  flex-direction: column;
}

.mini-label {
  color: #8e8798;
  font-size: 13px;
}

.pool-card.warning .mini-label {
  color: #fbbf24;
}

.mini-value {
  margin-top: 8px;
  color: #fff;
  font-size: 28px;
  font-weight: 700;
}

.pool-card.warning .mini-value {
  color: #f87171;
}

/* Filters */
.filters-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background:
    linear-gradient(180deg, rgb(255 255 255 / 3.5%), rgb(255 255 255 / 1.2%)),
    #16121d;
  box-shadow: inset 0 1px 0 rgb(255 255 255 / 4%);
}

.search-box {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
}

.search-box i {
  color: #b58cff;
  font-size: 14px;
}

.search-box input {
  border: none;
  background: transparent;
  color: #f6f2ff;
  font-size: 14px;
  outline: none;
  width: 200px;
}

.search-box input::placeholder {
  color: #777181;
}

.filter-group select {
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #f6f2ff;
  font-size: 14px;
  cursor: pointer;
}

/* Table */
.table-container {
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  box-shadow: 0 18px 50px rgb(0 0 0 / 26%);
  overflow: hidden;
}

.records-table {
  width: 100%;
  border-collapse: collapse;
}

.records-table th {
  padding: 16px;
  text-align: left;
  background: #211c29;
  color: #8e8798;
  font-size: 13px;
  font-weight: 600;
}

.records-table td {
  padding: 16px;
  border-bottom: 1px solid rgb(255 255 255 / 6%);
  color: #d8d0e4;
}

.records-table tr:hover td {
  background: rgb(255 255 255 / 4%);
}

.records-table td code {
  padding: 4px 8px;
  border-radius: 4px;
  background: #211c29;
  color: #b58cff;
  font-family: monospace;
  font-size: 12px;
}

.text-right {
  text-align: right;
}

.text-success {
  color: #14b8a6;
}

.text-primary {
  color: #60a5fa;
}

.text-danger {
  color: #f87171;
}

.level-badge {
  padding: 4px 10px;
  border-radius: 4px;
  background: rgba(103, 80, 164, 0.2);
  color: #c4b5fd;
  font-size: 12px;
  font-weight: 600;
}

.type-tag {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

.status-tag {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

.status-tag.pending {
  background: rgba(96, 165, 250, 0.2);
  color: #60a5fa;
}

.status-tag.completed {
  background: rgba(20, 184, 166, 0.2);
  color: #14b8a6;
}

.status-tag.failed {
  background: rgba(248, 113, 113, 0.2);
  color: #f87171;
}

.empty {
  color: #8e8798;
}

/* Empty State */
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 48px;
  color: #8e8798;
}

.empty-state i {
  font-size: 48px;
  margin-bottom: 12px;
}

/* Responsive */
@media (max-width: 900px) {
  .pool-cards {
    grid-template-columns: 1fr;
  }

  .filters-bar {
    flex-direction: column;
    gap: 12px;
  }

  .records-table {
    display: block;
    overflow-x: auto;
  }

  .search-box input {
    width: 100%;
  }
}
</style>