<script setup lang="ts">
import { ref, computed } from 'vue'

interface Wallet {
  id: string
  name: string
  type: 'hot' | 'cold' | 'company'
  balance: number
  currency: string
  status: 'active' | 'inactive' | 'maintenance'
  lastUpdate: string
}

interface Transaction {
  id: string
  type: 'deposit' | 'withdraw' | 'transfer' | 'fee'
  amount: number
  currency: string
  from?: string
  to?: string
  status: 'pending' | 'completed' | 'failed'
  description: string
  createdAt: string
}

const wallets = ref<Wallet[]>([
  { id: 'WAL001', name: '热钱包', type: 'hot', balance: 1250000, currency: 'USD', status: 'active', lastUpdate: '2024-05-28 10:30:00' },
  { id: 'WAL002', name: '冷钱包', type: 'cold', balance: 5000000, currency: 'USD', status: 'active', lastUpdate: '2024-05-28 09:00:00' },
  { id: 'WAL003', name: '公司账户', type: 'company', balance: 850000, currency: 'USD', status: 'active', lastUpdate: '2024-05-28 11:00:00' },
])

const transactions = ref<Transaction[]>([
  { id: 'TXN001', type: 'deposit', amount: 50000, currency: 'USD', to: '热钱包', status: 'completed', description: '用户充值', createdAt: '2024-05-28 10:30:00' },
  { id: 'TXN002', type: 'withdraw', amount: 25000, currency: 'USD', from: '热钱包', status: 'completed', description: '用户提现', createdAt: '2024-05-28 10:15:00' },
  { id: 'TXN003', type: 'transfer', amount: 100000, currency: 'USD', from: '热钱包', to: '冷钱包', status: 'completed', description: '资产转移', createdAt: '2024-05-28 09:30:00' },
  { id: 'TXN004', type: 'fee', amount: 500, currency: 'USD', to: '公司账户', status: 'completed', description: '交易手续费', createdAt: '2024-05-28 09:00:00' },
  { id: 'TXN005', type: 'deposit', amount: 100000, currency: 'USD', to: '热钱包', status: 'pending', description: '用户充值', createdAt: '2024-05-28 11:00:00' },
])

const searchQuery = ref('')
const typeFilter = ref('all')

const totalBalance = computed(() => {
  return wallets.value.reduce((sum, w) => sum + w.balance, 0)
})

const filteredTransactions = computed(() => {
  return transactions.value.filter(t => {
    const matchesSearch = t.id.includes(searchQuery.value) || 
                         t.description.includes(searchQuery.value)
    const matchesType = typeFilter.value === 'all' || t.type === typeFilter.value
    return matchesSearch && matchesType
  })
})

const typeColors: Record<string, string> = {
  deposit: '#14b8a6',
  withdraw: '#f87171',
  transfer: '#60a5fa',
  fee: '#fbbf24',
}

const typeLabels: Record<string, string> = {
  deposit: '充值',
  withdraw: '提现',
  transfer: '转账',
  fee: '手续费',
}

const statusLabels: Record<string, string> = {
  pending: '处理中',
  completed: '已完成',
  failed: '失败',
}
</script>

<template>
  <div class="finance-page">
    <!-- Header -->
    <div class="page-header">
      <div class="header-left">
        <h2>财务管理</h2>
        <p>全局钱包监控、公司账户余额、全局流水</p>
      </div>
      <div class="header-actions">
        <button class="btn-export">
          <i class="ri-download-2-line" aria-hidden="true"></i>
          导出流水
        </button>
      </div>
    </div>

    <!-- Total Balance Card -->
    <div class="total-balance-card">
      <div class="balance-info">
        <h3>总资产</h3>
        <div class="balance-amount">
          <span class="currency">$</span>
          <span class="amount">{{ totalBalance.toLocaleString() }}</span>
        </div>
        <p>实时更新</p>
      </div>
      <div class="balance-chart">
        <svg viewBox="0 0 100 100" class="pie-chart">
          <circle cx="50" cy="50" r="40" fill="rgba(255, 255, 255, 0.1)" />
          <circle cx="50" cy="50" r="40" fill="none" stroke="#60a5fa" stroke-width="20" stroke-dasharray="100.53 251.33" stroke-dashoffset="0" transform="rotate(-90 50 50)" />
          <circle cx="50" cy="50" r="40" fill="none" stroke="#8e8798" stroke-width="20" stroke-dasharray="150.8 251.33" stroke-dashoffset="-100.53" transform="rotate(-90 50 50)" />
          <circle cx="50" cy="50" r="40" fill="none" stroke="#c4b5fd" stroke-width="20" stroke-dasharray="62.83 251.33" stroke-dashoffset="-251.33" transform="rotate(-90 50 50)" />
        </svg>
      </div>
    </div>

    <!-- Wallet Cards -->
    <div class="wallets-grid">
      <div 
        v-for="wallet in wallets" 
        :key="wallet.id" 
        class="wallet-card"
        :class="wallet.type"
      >
        <div class="wallet-header">
          <div class="wallet-info">
            <i
              class="wallet-badge"
              :class="wallet.type === 'hot' ? 'ri-fire-line' : wallet.type === 'cold' ? 'ri-snowflake-line' : 'ri-building-4-line'"
              aria-hidden="true"
            ></i>
            <span class="wallet-name">{{ wallet.name }}</span>
          </div>
          <span 
            class="status-badge" 
            :class="wallet.status"
          >
            {{ wallet.status === 'active' ? '正常' : wallet.status === 'inactive' ? '停用' : '维护中' }}
          </span>
        </div>
        <div class="wallet-balance">
          <span class="currency">$</span>
          <span class="amount">{{ wallet.balance.toLocaleString() }}</span>
        </div>
        <div class="wallet-footer">
          <span class="last-update">更新于 {{ wallet.lastUpdate }}</span>
        </div>
      </div>
    </div>

    <!-- Filters -->
    <div class="filters-bar">
      <div class="search-box">
        <i class="ri-search-line" aria-hidden="true"></i>
        <input 
          v-model="searchQuery" 
          type="text" 
          placeholder="搜索交易ID、描述..."
        />
      </div>
      <div class="filter-group">
        <select v-model="typeFilter">
          <option value="all">全部类型</option>
          <option value="deposit">充值</option>
          <option value="withdraw">提现</option>
          <option value="transfer">转账</option>
          <option value="fee">手续费</option>
        </select>
      </div>
    </div>

    <!-- Transactions Table -->
    <div class="table-container">
      <table class="transactions-table">
        <thead>
          <tr>
            <th>交易ID</th>
            <th>类型</th>
            <th>金额</th>
            <th>来源</th>
            <th>目标</th>
            <th>状态</th>
            <th>描述</th>
            <th>时间</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="tx in filteredTransactions" :key="tx.id">
            <td><code>{{ tx.id }}</code></td>
            <td>
              <span 
                class="type-tag" 
                :style="{ backgroundColor: typeColors[tx.type] + '20', color: typeColors[tx.type] }"
              >
                {{ typeLabels[tx.type] }}
              </span>
            </td>
            <td>
              <strong 
                :class="{ 
                  'text-success': tx.type === 'deposit' || tx.type === 'fee',
                  'text-danger': tx.type === 'withdraw',
                  'text-primary': tx.type === 'transfer'
                }"
              >
                {{ tx.type === 'withdraw' ? '-' : '+' }}${{ tx.amount.toLocaleString() }}
              </strong>
            </td>
            <td>{{ tx.from || '-' }}</td>
            <td>{{ tx.to || '-' }}</td>
            <td>
              <span 
                class="status-tag" 
                :class="tx.status"
              >
                {{ statusLabels[tx.status] }}
              </span>
            </td>
            <td>{{ tx.description }}</td>
            <td>{{ tx.createdAt }}</td>
          </tr>
        </tbody>
      </table>

      <div v-if="filteredTransactions.length === 0" class="empty-state">
        <i class="ri-inbox-line" aria-hidden="true"></i>
        <p>没有找到匹配的交易记录</p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.finance-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 100%;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.header-left h2 {
  margin: 0 0 6px;
  color: #fff;
  font-size: 24px;
  font-weight: 700;
}

.header-left p {
  margin: 0;
  color: #8e8798;
  font-size: 14px;
}

.btn-export {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #d8d0e4;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-export:hover {
  background: rgb(103 80 164 / 18%);
  color: #fff;
}

/* Total Balance Card */
.total-balance-card {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 32px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: linear-gradient(135deg, #1e1829 0%, #16121d 100%);
}

.balance-info h3 {
  margin: 0 0 8px;
  color: #aaa3b6;
  font-size: 16px;
}

.balance-amount {
  display: flex;
  align-items: baseline;
  gap: 4px;
}

.balance-amount .currency {
  color: #aaa3b6;
  font-size: 28px;
}

.balance-amount .amount {
  color: #fff;
  font-size: 56px;
  font-weight: 700;
}

.balance-info p {
  margin: 8px 0 0;
  color: #14b8a6;
  font-size: 14px;
}

.balance-chart {
  width: 120px;
  height: 120px;
}

.pie-chart {
  transform: rotate(-90deg);
}

/* Wallet Cards */
.wallets-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}

.wallet-card {
  padding: 24px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
}

.wallet-card.hot {
  border-color: rgba(248, 113, 113, 0.3);
  background: rgba(248, 113, 113, 0.05);
}

.wallet-card.cold {
  border-color: rgba(96, 165, 250, 0.3);
  background: rgba(96, 165, 250, 0.05);
}

.wallet-card.company {
  border-color: rgba(251, 191, 36, 0.3);
  background: rgba(251, 191, 36, 0.05);
}

.wallet-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;
}

.wallet-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.wallet-badge {
  font-size: 20px;
}

.wallet-card.hot .wallet-badge {
  color: #f87171;
}

.wallet-card.cold .wallet-badge {
  color: #60a5fa;
}

.wallet-card.company .wallet-badge {
  color: #fbbf24;
}

.wallet-name {
  font-weight: 600;
  color: #f6f2ff;
}

.status-badge {
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

.status-badge.active {
  background: rgba(20, 184, 166, 0.2);
  color: #14b8a6;
}

.status-badge.inactive {
  background: rgba(142, 135, 152, 0.2);
  color: #8e8798;
}

.status-badge.maintenance {
  background: rgba(251, 191, 36, 0.2);
  color: #fbbf24;
}

.wallet-balance {
  display: flex;
  align-items: baseline;
  gap: 4px;
  margin-bottom: 12px;
}

.wallet-balance .currency {
  color: #8e8798;
  font-size: 16px;
}

.wallet-balance .amount {
  color: #fff;
  font-size: 32px;
  font-weight: 700;
}

.wallet-footer {
  padding-top: 12px;
  border-top: 1px solid rgb(255 255 255 / 6%);
}

.last-update {
  color: #8e8798;
  font-size: 12px;
}

/* Filters */
.filters-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background:
    linear-gradient(180deg, rgb(255 255 255 / 3.5%), rgb(255 255 255 / 1.2%)),
    #16121d;
  box-shadow: inset 0 1px 0 rgb(255 255 255 / 4%);
}

.search-box {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
}

.search-box i {
  color: #b58cff;
  font-size: 14px;
}

.search-box input {
  border: none;
  background: transparent;
  color: #f6f2ff;
  font-size: 14px;
  outline: none;
  width: 200px;
}

.search-box input::placeholder {
  color: #777181;
}

.filter-group select {
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #f6f2ff;
  font-size: 14px;
  cursor: pointer;
}

/* Table */
.table-container {
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  box-shadow: 0 18px 50px rgb(0 0 0 / 26%);
  overflow: hidden;
}

.transactions-table {
  width: 100%;
  border-collapse: collapse;
}

.transactions-table th {
  padding: 16px;
  text-align: left;
  background: #211c29;
  color: #8e8798;
  font-size: 13px;
  font-weight: 600;
}

.transactions-table td {
  padding: 16px;
  border-bottom: 1px solid rgb(255 255 255 / 6%);
  color: #d8d0e4;
}

.transactions-table tr:hover td {
  background: rgb(255 255 255 / 4%);
}

.transactions-table td code {
  padding: 4px 8px;
  border-radius: 4px;
  background: #211c29;
  color: #b58cff;
  font-family: monospace;
  font-size: 12px;
}

.text-success {
  color: #14b8a6;
}

.text-danger {
  color: #f87171;
}

.text-primary {
  color: #60a5fa;
}

.type-tag {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

.status-tag {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

.status-tag.pending {
  background: rgba(251, 191, 36, 0.2);
  color: #fbbf24;
}

.status-tag.completed {
  background: rgba(20, 184, 166, 0.2);
  color: #14b8a6;
}

.status-tag.failed {
  background: rgba(248, 113, 113, 0.2);
  color: #f87171;
}

/* Empty State */
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 48px;
  color: #8e8798;
}

.empty-state i {
  font-size: 48px;
  margin-bottom: 12px;
}

/* Responsive */
@media (max-width: 900px) {
  .total-balance-card {
    flex-direction: column;
    gap: 20px;
  }

  .wallets-grid {
    grid-template-columns: 1fr;
  }

  .filters-bar {
    flex-direction: column;
    gap: 12px;
  }

  .transactions-table {
    display: block;
    overflow-x: auto;
  }

  .search-box input {
    width: 100%;
  }
}
</style>