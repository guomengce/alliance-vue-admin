<script setup lang="ts">
import { ref, computed } from 'vue'

interface QueueItem {
  id: string
  user: string
  package: string
  totalLocked: number
  remainingLocked: number
  unlockedAmount: number
  progress: number
  status: 'locking' | 'unlocking' | 'completed'
  startedAt: string
  estimatedComplete: string
  unlockHistory: { date: string; amount: number }[]
}

const queueStats = ref({
  totalLocked: 2580000,
  activeUsers: 156,
  todayUnlocked: 85000,
  avgUnlockTime: '2.3天',
})

const queueItems = ref<QueueItem[]>([
  {
    id: 'QUE001',
    user: '张三',
    package: '套餐C',
    totalLocked: 50000,
    remainingLocked: 15000,
    unlockedAmount: 35000,
    progress: 70,
    status: 'unlocking',
    startedAt: '2024-05-20 10:00:00',
    estimatedComplete: '2024-05-29 10:00:00',
    unlockHistory: [
      { date: '2024-05-21', amount: 5000 },
      { date: '2024-05-22', amount: 5000 },
      { date: '2024-05-23', amount: 5000 },
      { date: '2024-05-24', amount: 5000 },
      { date: '2024-05-25', amount: 5000 },
      { date: '2024-05-26', amount: 5000 },
      { date: '2024-05-27', amount: 5000 },
    ],
  },
  {
    id: 'QUE002',
    user: '李四',
    package: '套餐E',
    totalLocked: 200000,
    remainingLocked: 200000,
    unlockedAmount: 0,
    progress: 0,
    status: 'locking',
    startedAt: '2024-05-28 09:15:00',
    estimatedComplete: '2024-09-25 09:15:00',
    unlockHistory: [],
  },
  {
    id: 'QUE003',
    user: '王五',
    package: '套餐A',
    totalLocked: 5000,
    remainingLocked: 0,
    unlockedAmount: 5000,
    progress: 100,
    status: 'completed',
    startedAt: '2024-04-28 11:20:00',
    estimatedComplete: '2024-05-28 11:20:00',
    unlockHistory: [],
  },
  {
    id: 'QUE004',
    user: '赵六',
    package: '套餐D',
    totalLocked: 100000,
    remainingLocked: 40000,
    unlockedAmount: 60000,
    progress: 60,
    status: 'unlocking',
    startedAt: '2024-05-18 16:45:00',
    estimatedComplete: '2024-06-02 16:45:00',
    unlockHistory: [
      { date: '2024-05-19', amount: 6667 },
      { date: '2024-05-20', amount: 6667 },
      { date: '2024-05-21', amount: 6667 },
      { date: '2024-05-22', amount: 6667 },
      { date: '2024-05-23', amount: 6667 },
      { date: '2024-05-24', amount: 6667 },
      { date: '2024-05-25', amount: 6667 },
      { date: '2024-05-26', amount: 6667 },
      { date: '2024-05-27', amount: 6667 },
    ],
  },
])

const searchQuery = ref('')
const statusFilter = ref('all')

const filteredQueue = computed(() => {
  return queueItems.value.filter(item => {
    const matchesSearch = item.id.includes(searchQuery.value) || 
                         item.user.includes(searchQuery.value) ||
                         item.package.includes(searchQuery.value)
    const matchesStatus = statusFilter.value === 'all' || item.status === statusFilter.value
    return matchesSearch && matchesStatus
  })
})

const statusColors: Record<string, string> = {
  locking: '#60a5fa',
  unlocking: '#14b8a6',
  completed: '#8e8798',
}

const statusLabels: Record<string, string> = {
  locking: '锁定中',
  unlocking: '解锁中',
  completed: '已完成',
}
</script>

<template>
  <div class="queue-page">
    <!-- Header -->
    <div class="page-header">
      <div class="header-left">
        <h2>排队管理</h2>
        <p>锁定总金额监控、各会员解锁进度列表</p>
      </div>
      <div class="header-actions">
        <button class="btn-export">
          <i class="ri-download-2-line" aria-hidden="true"></i>
          导出数据
        </button>
      </div>
    </div>

    <!-- Stats Cards -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon"><i class="ri-lock-2-line" aria-hidden="true"></i></div>
        <div class="stat-info">
          <p class="stat-title">锁定总金额</p>
          <h3 class="stat-value">${{ queueStats.totalLocked.toLocaleString() }}</h3>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon"><i class="ri-team-line" aria-hidden="true"></i></div>
        <div class="stat-info">
          <p class="stat-title">进行中用户</p>
          <h3 class="stat-value">{{ queueStats.activeUsers }}</h3>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon"><i class="ri-upload-2-line" aria-hidden="true"></i></div>
        <div class="stat-info">
          <p class="stat-title">今日解锁</p>
          <h3 class="stat-value">${{ queueStats.todayUnlocked.toLocaleString() }}</h3>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon"><i class="ri-timer-line" aria-hidden="true"></i></div>
        <div class="stat-info">
          <p class="stat-title">平均周期</p>
          <h3 class="stat-value">{{ queueStats.avgUnlockTime }}</h3>
        </div>
      </div>
    </div>

    <!-- Filters -->
    <div class="filters-bar">
      <div class="search-box">
        <i class="ri-search-line" aria-hidden="true"></i>
        <input 
          v-model="searchQuery" 
          type="text" 
          placeholder="搜索排队ID、用户、套餐..."
        />
      </div>
      <div class="filter-group">
        <select v-model="statusFilter">
          <option value="all">全部状态</option>
          <option value="locking">锁定中</option>
          <option value="unlocking">解锁中</option>
          <option value="completed">已完成</option>
        </select>
      </div>
    </div>

    <!-- Queue List -->
    <div class="queue-list">
      <div 
        v-for="item in filteredQueue" 
        :key="item.id" 
        class="queue-card"
      >
        <div class="card-header">
          <div class="queue-info">
            <code>{{ item.id }}</code>
            <span class="user-name">{{ item.user }}</span>
            <span class="package-name">{{ item.package }}</span>
          </div>
          <span 
            class="status-badge" 
            :style="{ backgroundColor: statusColors[item.status] + '20', color: statusColors[item.status] }"
          >
            {{ statusLabels[item.status] }}
          </span>
        </div>

        <div class="progress-section">
          <div class="progress-header">
            <span>解锁进度</span>
            <span class="progress-percent">{{ item.progress }}%</span>
          </div>
          <div class="progress-bar">
            <div 
              class="progress-fill" 
              :style="{ width: item.progress + '%' }"
              :class="item.status"
            ></div>
          </div>
          <div class="progress-details">
            <span>已解锁: <strong>${{ item.unlockedAmount.toLocaleString() }}</strong></span>
            <span>剩余: <strong>${{ item.remainingLocked.toLocaleString() }}</strong></span>
          </div>
        </div>

        <div class="time-info">
          <div>
            <span class="time-label">开始时间</span>
            <span>{{ item.startedAt }}</span>
          </div>
          <div>
            <span class="time-label">预计完成</span>
            <span>{{ item.estimatedComplete }}</span>
          </div>
        </div>

        <div v-if="item.unlockHistory.length > 0" class="history-section">
          <span class="history-title">解锁记录</span>
          <div class="history-list">
            <div 
              v-for="(record, index) in item.unlockHistory.slice(-7)" 
              :key="index" 
              class="history-item"
            >
              <span class="history-date">{{ record.date }}</span>
              <span class="history-amount">+${{ record.amount.toLocaleString() }}</span>
            </div>
          </div>
        </div>
      </div>

      <div v-if="filteredQueue.length === 0" class="empty-state">
        <i class="ri-inbox-line" aria-hidden="true"></i>
        <p>没有找到匹配的排队记录</p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.queue-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 100%;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.header-left h2 {
  margin: 0 0 6px;
  color: #fff;
  font-size: 24px;
  font-weight: 700;
}

.header-left p {
  margin: 0;
  color: #8e8798;
  font-size: 14px;
}

.btn-export {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #d8d0e4;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-export:hover {
  background: rgb(103 80 164 / 18%);
  color: #fff;
}

/* Stats */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
}

.stat-icon {
  display: flex;
  width: 48px;
  height: 48px;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  background: rgba(103, 80, 164, 0.2);
  color: #c4b5fd;
  font-size: 24px;
}

.stat-info {
  flex: 1;
}

.stat-title {
  margin: 0;
  color: #8e8798;
  font-size: 13px;
}

.stat-value {
  margin: 4px 0 0;
  color: #fff;
  font-size: 24px;
  font-weight: 700;
}

/* Filters */
.filters-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background:
    linear-gradient(180deg, rgb(255 255 255 / 3.5%), rgb(255 255 255 / 1.2%)),
    #16121d;
  box-shadow: inset 0 1px 0 rgb(255 255 255 / 4%);
}

.search-box {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
}

.search-box i {
  color: #b58cff;
  font-size: 14px;
}

.search-box input {
  border: none;
  background: transparent;
  color: #f6f2ff;
  font-size: 14px;
  outline: none;
  width: 200px;
}

.search-box input::placeholder {
  color: #777181;
}

.filter-group select {
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #f6f2ff;
  font-size: 14px;
  cursor: pointer;
}

/* Queue List */
.queue-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.queue-card {
  padding: 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  box-shadow: 0 18px 50px rgb(0 0 0 / 26%);
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 16px;
}

.queue-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.queue-info code {
  padding: 4px 10px;
  border-radius: 4px;
  background: #211c29;
  color: #b58cff;
  font-family: monospace;
  font-size: 12px;
}

.user-name {
  font-weight: 600;
  color: #f6f2ff;
}

.package-name {
  padding: 4px 10px;
  border-radius: 4px;
  background: rgba(251, 191, 36, 0.15);
  color: #fbbf24;
  font-size: 12px;
  font-weight: 600;
}

.status-badge {
  padding: 6px 14px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

.progress-section {
  margin-bottom: 16px;
}

.progress-header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
}

.progress-header span:first-child {
  color: #8e8798;
  font-size: 13px;
}

.progress-percent {
  color: #c4b5fd;
  font-size: 14px;
  font-weight: 700;
}

.progress-bar {
  height: 10px;
  border-radius: 6px;
  background: rgba(255, 255, 255, 0.1);
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  border-radius: 6px;
  transition: width 0.3s ease;
}

.progress-fill.locking {
  background: linear-gradient(90deg, #60a5fa, #3b82f6);
}

.progress-fill.unlocking {
  background: linear-gradient(90deg, #14b8a6, #10b981);
}

.progress-fill.completed {
  background: linear-gradient(90deg, #8e8798, #aaa3b6);
}

.progress-details {
  display: flex;
  justify-content: space-between;
  margin-top: 8px;
}

.progress-details span {
  color: #8e8798;
  font-size: 13px;
}

.progress-details strong {
  color: #f6f2ff;
}

.time-info {
  display: flex;
  gap: 32px;
  padding: 12px 16px;
  border-radius: 8px;
  background: #211c29;
  margin-bottom: 16px;
}

.time-info div {
  display: flex;
  flex-direction: column;
}

.time-label {
  color: #8e8798;
  font-size: 12px;
}

.time-info span:last-child {
  margin-top: 4px;
  color: #f6f2ff;
  font-size: 14px;
  font-weight: 600;
}

.history-section {
  border-top: 1px solid rgb(255 255 255 / 6%);
  padding-top: 16px;
}

.history-title {
  display: block;
  margin-bottom: 12px;
  color: #8e8798;
  font-size: 13px;
}

.history-list {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 8px;
}

.history-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 10px;
  border-radius: 8px;
  background: #211c29;
}

.history-date {
  color: #8e8798;
  font-size: 11px;
}

.history-amount {
  margin-top: 4px;
  color: #14b8a6;
  font-size: 13px;
  font-weight: 600;
}

/* Empty State */
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 48px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  color: #8e8798;
}

.empty-state i {
  font-size: 48px;
  margin-bottom: 12px;
}

/* Responsive */
@media (max-width: 900px) {
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }

  .filters-bar {
    flex-direction: column;
    gap: 12px;
  }

  .history-list {
    grid-template-columns: repeat(4, 1fr);
  }

  .search-box input {
    width: 100%;
  }
}

@media (max-width: 640px) {
  .stats-grid {
    grid-template-columns: 1fr;
  }

  .time-info {
    flex-direction: column;
    gap: 12px;
  }

  .history-list {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>