<script setup lang="ts">
import { reactive, ref } from 'vue'
import { useAppRouter } from '@app/router'
import { useSessionStore } from '@stores/session'

const router = useAppRouter()
const session = useSessionStore()
const errorMessage = ref('')
const showPassword = ref(false)
const form = reactive({
  account: 'admin',
  password: 'admin123',
})

const submit = async () => {
  errorMessage.value = ''

  try {
    await session.login(form.account, form.password)
    router.replace('/')
  } catch (error) {
    errorMessage.value = error instanceof Error ? error.message : '登录失败'
  }
}
</script>

<template>
  <main class="login-page">
    <div class="login-decoration" aria-hidden="true"></div>
    <section class="login-panel" aria-label="登录表单">
      <div class="login-emblem" aria-hidden="true">
        <span>🔒</span>
      </div>

      <div class="panel-heading">
        <h1>后台管理系统</h1>
        <p>
          <span class="login-heading-line"></span>
          管理员登录
          <span class="login-heading-line"></span>
        </p>
      </div>

      <form class="login-form" @submit.prevent="submit">
        <label class="login-field">
          <span class="field-icon" aria-hidden="true">♙</span>
          <input v-model="form.account" autocomplete="username" placeholder="用户名" />
        </label>
        <label class="login-field">
          <span class="field-icon" aria-hidden="true">▣</span>
          <input
            v-model="form.password"
            autocomplete="current-password"
            placeholder="密码"
            :type="showPassword ? 'text' : 'password'"
          />
          <button
            class="password-toggle"
            type="button"
            :aria-label="showPassword ? '隐藏密码' : '显示密码'"
            @click="showPassword = !showPassword"
          >
            ◉
          </button>
        </label>

        <p v-if="errorMessage" class="form-error">{{ errorMessage }}</p>

        <button class="primary-button" type="submit" :disabled="session.state.loading">
          {{ session.state.loading ? '登录中...' : '登录' }}
        </button>
      </form>
    </section>
  </main>
</template>
