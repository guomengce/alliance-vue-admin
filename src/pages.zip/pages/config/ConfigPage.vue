<script setup lang="ts">
import { ref } from 'vue'

interface LevelConfig {
  level: string
  rate: number
  description: string
}

interface SystemParam {
  id: string
  name: string
  value: string | number | boolean
  type: 'string' | 'number' | 'boolean'
  description: string
}

interface PriceSource {
  id: string
  name: string
  url: string
  apiKey: string
  enabled: boolean
  priority: number
}

const levelConfigs = ref<LevelConfig[]>([
  { level: 'L1', rate: 10, description: '第一层佣金比例' },
  { level: 'L2', rate: 8, description: '第二层佣金比例' },
  { level: 'L3', rate: 5, description: '第三层佣金比例' },
  { level: 'L4', rate: 3, description: '第四层佣金比例' },
  { level: 'L5', rate: 2, description: '第五层佣金比例' },
])

const systemParams = ref<SystemParam[]>([
  { id: 'param001', name: '每日提现限额', value: 50000, type: 'number', description: '用户每日最大提现金额' },
  { id: 'param002', name: '最小投资金额', value: 100, type: 'number', description: '用户最小投资金额' },
  { id: 'param003', name: '自动结算开关', value: true, type: 'boolean', description: '是否开启D+1自动结算' },
  { id: 'param004', name: '风控审核阈值', value: 100000, type: 'number', description: '超过此金额需人工审核' },
  { id: 'param005', name: '结算时间', value: '00:00', type: 'string', description: '每日自动结算执行时间' },
])

const priceSources = ref<PriceSource[]>([
  { id: 'src001', name: 'CoinGecko', url: 'https://api.coingecko.com/v3/', apiKey: '******', enabled: true, priority: 1 },
  { id: 'src002', name: 'Binance', url: 'https://api.binance.com/api/v3/', apiKey: '******', enabled: true, priority: 2 },
  { id: 'src003', name: 'CoinMarketCap', url: 'https://pro-api.coinmarketcap.com/v1/', apiKey: '******', enabled: false, priority: 3 },
])

const activeTab = ref('levels')

const saveLevelConfigs = () => {
  alert('等级配置已保存')
}

const saveSystemParams = () => {
  alert('系统参数已保存')
}

const savePriceSources = () => {
  alert('价格源配置已保存')
}

const togglePriceSource = (source: PriceSource) => {
  source.enabled = !source.enabled
}
</script>

<template>
  <div class="config-page">
    <!-- Header -->
    <div class="page-header">
      <div class="header-left">
        <h2>参数配置</h2>
        <p>L1-L5比例调整、系统参数设置、TROO价格源API配置</p>
      </div>
    </div>

    <!-- Tabs -->
    <div class="tabs">
      <button 
        class="tab-btn" 
        :class="{ active: activeTab === 'levels' }"
        @click="activeTab = 'levels'"
      >
        <i class="ri-bar-chart-box-line" aria-hidden="true"></i>
        等级配置
      </button>
      <button 
        class="tab-btn" 
        :class="{ active: activeTab === 'system' }"
        @click="activeTab = 'system'"
      >
        <i class="ri-settings-3-line" aria-hidden="true"></i>
        系统参数
      </button>
      <button 
        class="tab-btn" 
        :class="{ active: activeTab === 'price' }"
        @click="activeTab = 'price'"
      >
        <i class="ri-coins-line" aria-hidden="true"></i>
        价格源
      </button>
    </div>

    <!-- Level Configuration -->
    <div v-show="activeTab === 'levels'" class="config-panel">
      <div class="panel-header">
        <h3>L1-L5 佣金比例配置</h3>
        <button class="btn-primary" @click="saveLevelConfigs">
          <i class="ri-save-3-line" aria-hidden="true"></i>
          保存配置
        </button>
      </div>

      <div class="config-form">
        <div 
          v-for="config in levelConfigs" 
          :key="config.level" 
          class="config-item"
        >
          <div class="config-label">
            <span class="level-badge">{{ config.level }}</span>
            <span class="config-name">{{ config.description }}</span>
          </div>
          <div class="config-input-group">
            <input 
              v-model.number="config.rate" 
              type="number" 
              min="0" 
              max="100"
              step="0.1"
              class="rate-input"
            />
            <span class="rate-unit">%</span>
          </div>
        </div>
      </div>

      <div class="config-summary">
        <div class="summary-row">
          <span>总佣金比例</span>
          <span class="summary-value">
            {{ levelConfigs.reduce((sum, c) => sum + c.rate, 0).toFixed(1) }}%
          </span>
        </div>
      </div>
    </div>

    <!-- System Parameters -->
    <div v-show="activeTab === 'system'" class="config-panel">
      <div class="panel-header">
        <h3>系统参数设置</h3>
        <button class="btn-primary" @click="saveSystemParams">
          <i class="ri-save-3-line" aria-hidden="true"></i>
          保存配置
        </button>
      </div>

      <div class="params-grid">
        <div 
          v-for="param in systemParams" 
          :key="param.id" 
          class="param-card"
        >
          <div class="param-header">
            <span class="param-name">{{ param.name }}</span>
            <span class="param-type">{{ param.type }}</span>
          </div>
          <p class="param-desc">{{ param.description }}</p>
          <div class="param-value">
            <input 
              v-if="param.type === 'number'"
              v-model.number="param.value" 
              type="number"
              class="param-input"
            />
            <input 
              v-else-if="param.type === 'string'"
              v-model="param.value" 
              type="text"
              class="param-input"
            />
            <label v-else class="param-switch">
              <input 
                v-model="param.value" 
                type="checkbox"
              />
              <span class="slider"></span>
            </label>
          </div>
        </div>
      </div>
    </div>

    <!-- Price Sources -->
    <div v-show="activeTab === 'price'" class="config-panel">
      <div class="panel-header">
        <h3>TROO 价格源 API 配置</h3>
        <button class="btn-primary" @click="savePriceSources">
          <i class="ri-save-3-line" aria-hidden="true"></i>
          保存配置
        </button>
      </div>

      <div class="sources-list">
        <div 
          v-for="source in priceSources" 
          :key="source.id" 
          class="source-card"
          :class="{ 'is-disabled': !source.enabled }"
        >
          <div class="source-header">
            <div class="source-info">
              <span class="source-name">{{ source.name }}</span>
              <span class="priority-badge">优先级 {{ source.priority }}</span>
            </div>
            <label class="source-switch">
              <input 
                v-model="source.enabled" 
                type="checkbox"
                @change="togglePriceSource(source)"
              />
              <span class="slider"></span>
            </label>
          </div>

          <div class="source-url">
            <span class="url-label">API 地址</span>
            <code>{{ source.url }}</code>
          </div>

          <div class="source-api">
            <span class="api-label">API Key</span>
            <code>{{ source.apiKey }}</code>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.config-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 100%;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.header-left h2 {
  margin: 0 0 6px;
  color: #fff;
  font-size: 24px;
  font-weight: 700;
}

.header-left p {
  margin: 0;
  color: #8e8798;
  font-size: 14px;
}

/* Tabs */
.tabs {
  display: flex;
  gap: 8px;
}

.tab-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 24px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  color: #8e8798;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.tab-btn.active {
  border-color: #6750a4;
  background: rgba(103, 80, 164, 0.2);
  color: #c4b5fd;
}

/* Config Panel */
.config-panel {
  padding: 24px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  box-shadow: 0 18px 50px rgb(0 0 0 / 26%);
}

.panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 24px;
}

.panel-header h3 {
  margin: 0;
  color: #fff;
  font-size: 18px;
}

.btn-primary {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  border: none;
  border-radius: 8px;
  background: linear-gradient(135deg, #6750a4 0%, #6750a4 100%);
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 24px rgb(103 80 164 / 30%);
}

/* Level Config Form */
.config-form {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.config-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px;
  border-radius: 8px;
  background: #211c29;
}

.config-label {
  display: flex;
  align-items: center;
  gap: 12px;
}

.level-badge {
  padding: 6px 14px;
  border-radius: 6px;
  background: linear-gradient(135deg, #6750a4 0%, #6750a4 100%);
  color: #fff;
  font-size: 14px;
  font-weight: 700;
}

.config-name {
  color: #d8d0e4;
  font-size: 14px;
}

.config-input-group {
  display: flex;
  align-items: center;
  gap: 8px;
}

.rate-input {
  width: 80px;
  padding: 10px 14px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  color: #fff;
  font-size: 16px;
  font-weight: 600;
  text-align: center;
  outline: none;
}

.rate-input:focus {
  border-color: #6750a4;
}

.rate-unit {
  color: #8e8798;
  font-size: 16px;
  font-weight: 600;
}

.config-summary {
  margin-top: 20px;
  padding: 16px;
  border-radius: 8px;
  background: rgba(251, 191, 36, 0.1);
}

.summary-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.summary-row span:first-child {
  color: #fbbf24;
  font-size: 14px;
}

.summary-value {
  color: #fbbf24;
  font-size: 24px;
  font-weight: 700;
}

/* Params Grid */
.params-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
}

.param-card {
  padding: 20px;
  border-radius: 8px;
  background: #211c29;
}

.param-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
}

.param-name {
  font-weight: 600;
  color: #f6f2ff;
}

.param-type {
  padding: 2px 8px;
  border-radius: 4px;
  background: rgba(103, 80, 164, 0.2);
  color: #c4b5fd;
  font-size: 11px;
}

.param-desc {
  margin: 0 0 12px;
  color: #8e8798;
  font-size: 13px;
}

.param-value {
  display: flex;
  align-items: center;
}

.param-input {
  flex: 1;
  padding: 10px 14px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  color: #f6f2ff;
  font-size: 14px;
  outline: none;
}

.param-input:focus {
  border-color: #6750a4;
}

.param-switch {
  position: relative;
  display: inline-block;
  width: 56px;
  height: 32px;
}

.param-switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.param-switch .slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 32px;
  transition: 0.3s;
}

.param-switch .slider:before {
  position: absolute;
  content: '';
  height: 24px;
  width: 24px;
  left: 4px;
  bottom: 4px;
  background: #8e8798;
  border-radius: 50%;
  transition: 0.3s;
}

.param-switch input:checked + .slider {
  background: #6750a4;
}

.param-switch input:checked + .slider:before {
  transform: translateX(24px);
  background: #fff;
}

</style>