<script setup lang="ts">
import { ref, computed } from 'vue'

interface Order {
  id: string
  user: string
  package: string
  amount: number
  status: 'pending' | 'processing' | 'completed' | 'cancelled'
  type: 'buy' | 'sell' | 'invest' | 'withdraw'
  createdAt: string
  updatedAt: string
  details?: {
    flow: string[]
    fee: number
    netAmount: number
  }
}

const orders = ref<Order[]>([
  { id: 'ORD20240528001', user: '张三', package: '套餐C', amount: 50000, status: 'completed', type: 'invest', createdAt: '2024-05-28 10:30:25', updatedAt: '2024-05-28 10:35:12', details: { flow: ['用户下单', '支付成功', '套餐激活', '收益开始'], fee: 250, netAmount: 49750 } },
  { id: 'ORD20240528002', user: '李四', package: '套餐E', amount: 200000, status: 'processing', type: 'invest', createdAt: '2024-05-28 09:15:40', updatedAt: '2024-05-28 09:18:33', details: { flow: ['用户下单', '支付处理中'], fee: 1000, netAmount: 199000 } },
  { id: 'ORD20240528003', user: '王五', package: '套餐A', amount: 5000, status: 'pending', type: 'invest', createdAt: '2024-05-28 11:20:00', updatedAt: '2024-05-28 11:20:00' },
  { id: 'ORD20240528004', user: '赵六', package: '套餐D', amount: 100000, status: 'completed', type: 'invest', createdAt: '2024-05-27 16:45:12', updatedAt: '2024-05-27 16:50:08', details: { flow: ['用户下单', '支付成功', '套餐激活', '收益开始'], fee: 500, netAmount: 99500 } },
  { id: 'ORD20240528005', user: '孙七', package: '套餐B', amount: 30000, status: 'cancelled', type: 'invest', createdAt: '2024-05-26 08:30:00', updatedAt: '2024-05-26 08:45:00' },
])

const searchQuery = ref('')
const statusFilter = ref('all')
const typeFilter = ref('all')
const selectedOrder = ref<Order | null>(null)
const showDetailModal = ref(false)

const filteredOrders = computed(() => {
  return orders.value.filter(order => {
    const matchesSearch = order.id.includes(searchQuery.value) || 
                         order.user.includes(searchQuery.value) ||
                         order.package.includes(searchQuery.value)
    const matchesStatus = statusFilter.value === 'all' || order.status === statusFilter.value
    const matchesType = typeFilter.value === 'all' || order.type === typeFilter.value
    return matchesSearch && matchesStatus && matchesType
  })
})

const statusColors: Record<string, string> = {
  pending: '#60a5fa',
  processing: '#fbbf24',
  completed: '#14b8a6',
  cancelled: '#f87171',
}

const statusLabels: Record<string, string> = {
  pending: '待处理',
  processing: '处理中',
  completed: '已完成',
  cancelled: '已取消',
}

const typeLabels: Record<string, string> = {
  buy: '购买',
  sell: '出售',
  invest: '投资',
  withdraw: '提现',
}

const openDetailModal = (order: Order) => {
  selectedOrder.value = order
  showDetailModal.value = true
}

const closeDetailModal = () => {
  showDetailModal.value = false
  selectedOrder.value = null
}

const confirmOrder = (order: Order) => {
  if (order.status === 'pending') {
    order.status = 'processing'
  } else if (order.status === 'processing') {
    order.status = 'completed'
  }
}

const cancelOrder = (order: Order) => {
  if (order.status !== 'completed') {
    order.status = 'cancelled'
  }
}
</script>

<template>
  <div class="orders-page">
    <!-- Header -->
    <div class="page-header">
      <div class="header-left">
        <h2>订单管理</h2>
        <p>订单筛选列表、资金流向拆分详情</p>
      </div>
      <div class="header-actions">
        <button class="btn-export">
          <i class="ri-download-2-line" aria-hidden="true"></i>
          导出订单
        </button>
      </div>
    </div>

    <!-- Filters -->
    <div class="filters-bar">
      <div class="search-box">
        <i class="ri-search-line" aria-hidden="true"></i>
        <input 
          v-model="searchQuery" 
          type="text" 
          placeholder="搜索订单号、用户、套餐..."
        />
      </div>
      <div class="filter-group">
        <select v-model="statusFilter">
          <option value="all">全部状态</option>
          <option value="pending">待处理</option>
          <option value="processing">处理中</option>
          <option value="completed">已完成</option>
          <option value="cancelled">已取消</option>
        </select>
        <select v-model="typeFilter">
          <option value="all">全部类型</option>
          <option value="buy">购买</option>
          <option value="sell">出售</option>
          <option value="invest">投资</option>
          <option value="withdraw">提现</option>
        </select>
      </div>
    </div>

    <!-- Stats Cards -->
    <div class="stats-row">
      <div class="stat-item total">
        <strong>${{ orders.reduce((sum, o) => sum + o.amount, 0).toLocaleString() }}</strong>
        <span>订单总额</span>
      </div>
      <div class="stat-item pending">
        <strong>{{ orders.filter(o => o.status === 'pending').length }}</strong>
        <span>待处理</span>
      </div>
      <div class="stat-item processing">
        <strong>{{ orders.filter(o => o.status === 'processing').length }}</strong>
        <span>处理中</span>
      </div>
      <div class="stat-item completed">
        <strong>{{ orders.filter(o => o.status === 'completed').length }}</strong>
        <span>已完成</span>
      </div>
    </div>

    <!-- Orders Table -->
    <div class="table-container">
      <table class="orders-table">
        <thead>
          <tr>
            <th>订单号</th>
            <th>用户</th>
            <th>套餐</th>
            <th>金额</th>
            <th>类型</th>
            <th>状态</th>
            <th>创建时间</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="order in filteredOrders" :key="order.id">
            <td><code>{{ order.id }}</code></td>
            <td>{{ order.user }}</td>
            <td>{{ order.package }}</td>
            <td class="text-right">
              <strong>${{ order.amount.toLocaleString() }}</strong>
            </td>
            <td>
              <span class="type-tag">{{ typeLabels[order.type] }}</span>
            </td>
            <td>
              <span 
                class="status-tag" 
                :style="{ backgroundColor: statusColors[order.status] + '20', color: statusColors[order.status] }"
              >
                {{ statusLabels[order.status] }}
              </span>
            </td>
            <td>{{ order.createdAt }}</td>
            <td>
              <div class="actions">
                <button 
                  class="action-btn detail-btn" 
                  @click="openDetailModal(order)"
                  title="查看详情"
                >
                  <i class="ri-eye-line" aria-hidden="true"></i>
                </button>
                <button 
                  v-if="order.status === 'pending'" 
                  class="action-btn success-btn" 
                  @click="confirmOrder(order)"
                  title="确认订单"
                >
                  <i class="ri-check-line" aria-hidden="true"></i>
                </button>
                <button 
                  v-if="order.status !== 'completed'" 
                  class="action-btn danger-btn" 
                  @click="cancelOrder(order)"
                  title="取消订单"
                >
                  <i class="ri-close-line" aria-hidden="true"></i>
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      <div v-if="filteredOrders.length === 0" class="empty-state">
        <i class="ri-inbox-line" aria-hidden="true"></i>
        <p>没有找到匹配的订单</p>
      </div>
    </div>

    <!-- Detail Modal -->
    <div v-if="showDetailModal" class="modal-overlay" @click="closeDetailModal">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <div>
            <h3>订单详情</h3>
            <span class="order-id">{{ selectedOrder?.id }}</span>
          </div>
          <button class="close-btn" @click="closeDetailModal">
            <i class="ri-close-line" aria-hidden="true"></i>
          </button>
        </div>
        <div class="modal-body">
          <div class="detail-section">
            <h4>基本信息</h4>
            <div class="detail-grid">
              <div class="detail-item">
                <span class="label">用户</span>
                <span class="value">{{ selectedOrder?.user }}</span>
              </div>
              <div class="detail-item">
                <span class="label">套餐</span>
                <span class="value">{{ selectedOrder?.package }}</span>
              </div>
              <div class="detail-item">
                <span class="label">金额</span>
                <span class="value amount">${{ selectedOrder?.amount.toLocaleString() }}</span>
              </div>
              <div class="detail-item">
                <span class="label">类型</span>
                <span class="value">{{ typeLabels[selectedOrder?.type || 'invest'] }}</span>
              </div>
              <div class="detail-item">
                <span class="label">状态</span>
                <span 
                  class="value status"
                  :style="{ color: statusColors[selectedOrder?.status || 'pending'] }"
                >
                  {{ statusLabels[selectedOrder?.status || 'pending'] }}
                </span>
              </div>
              <div class="detail-item">
                <span class="label">创建时间</span>
                <span class="value">{{ selectedOrder?.createdAt }}</span>
              </div>
            </div>
          </div>

          <div v-if="selectedOrder?.details" class="detail-section">
            <h4>资金流向</h4>
            <div class="flow-timeline">
              <div 
                v-for="(step, index) in selectedOrder.details.flow" 
                :key="index" 
                class="flow-step"
                :class="{ 'is-active': index === selectedOrder.details.flow.length - 1 }"
              >
                <span class="flow-dot"></span>
                <span class="flow-line"></span>
                <span class="flow-text">{{ step }}</span>
              </div>
            </div>
            <div class="fee-details">
              <div>
                <span>手续费</span>
                <span class="fee">-${{ selectedOrder.details.fee.toLocaleString() }}</span>
              </div>
              <div>
                <span>到账金额</span>
                <span class="net">${{ selectedOrder.details.netAmount.toLocaleString() }}</span>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-secondary" @click="closeDetailModal">关闭</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.orders-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 100%;
  color: #f6f2ff;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.header-left h2 {
  margin: 0 0 6px;
  color: #fff;
  font-size: 24px;
  font-weight: 700;
}

.header-left p {
  margin: 0;
  color: #8e8798;
  font-size: 14px;
}

.btn-export {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #d8d0e4;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-export:hover {
  background: rgb(103 80 164 / 18%);
  color: #fff;
}

/* Filters */
.filters-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background:
    linear-gradient(180deg, rgb(255 255 255 / 3.5%), rgb(255 255 255 / 1.2%)),
    #16121d;
  box-shadow: inset 0 1px 0 rgb(255 255 255 / 4%);
}

.search-box {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
}

.search-box i {
  color: #b58cff;
  font-size: 14px;
}

.search-box input {
  border: none;
  background: transparent;
  color: #f6f2ff;
  font-size: 14px;
  outline: none;
  width: 200px;
}

.search-box input::placeholder {
  color: #777181;
}

.filter-group {
  display: flex;
  gap: 12px;
}

.filter-group select {
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #f6f2ff;
  font-size: 14px;
  cursor: pointer;
}

/* Stats */
.stats-row {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}

.stat-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
}

.stat-item strong {
  font-size: 28px;
  font-weight: 700;
  color: #fff;
}

.stat-item span {
  margin-top: 4px;
  color: #8e8798;
  font-size: 13px;
}

.stat-item.total strong {
  color: #c4b5fd;
}

.stat-item.pending strong {
  color: #60a5fa;
}

.stat-item.processing strong {
  color: #fbbf24;
}

.stat-item.completed strong {
  color: #14b8a6;
}

/* Table */
.table-container {
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  box-shadow: 0 18px 50px rgb(0 0 0 / 26%);
  overflow: hidden;
}

.orders-table {
  width: 100%;
  border-collapse: collapse;
}

.orders-table th {
  padding: 16px;
  text-align: left;
  background: #211c29;
  color: #8e8798;
  font-size: 13px;
  font-weight: 600;
}

.orders-table td {
  padding: 16px;
  border-bottom: 1px solid rgb(255 255 255 / 6%);
  color: #d8d0e4;
}

.orders-table tr:hover td {
  background: rgb(255 255 255 / 4%);
}

.orders-table td code {
  padding: 4px 8px;
  border-radius: 4px;
  background: #211c29;
  color: #b58cff;
  font-family: monospace;
  font-size: 12px;
}

.text-right {
  text-align: right;
}

.text-right strong {
  color: #c4b5fd;
}

.type-tag {
  padding: 4px 10px;
  border-radius: 4px;
  background: rgba(103, 80, 164, 0.2);
  color: #c4b5fd;
  font-size: 12px;
  font-weight: 600;
}

.status-tag {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

/* Actions */
.actions {
  display: flex;
  gap: 8px;
}

.action-btn {
  display: flex;
  width: 32px;
  height: 32px;
  align-items: center;
  justify-content: center;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.detail-btn {
  background: rgba(103, 80, 164, 0.2);
  color: #b58cff;
}

.detail-btn:hover {
  background: rgba(103, 80, 164, 0.35);
}

.success-btn {
  background: rgba(13, 118, 110, 0.2);
  color: #14b8a6;
}

.success-btn:hover {
  background: rgba(13, 118, 110, 0.35);
}

.danger-btn {
  background: rgba(180, 35, 24, 0.2);
  color: #f87171;
}

.danger-btn:hover {
  background: rgba(180, 35, 24, 0.35);
}

/* Empty State */
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 48px;
  color: #8e8798;
}

.empty-state i {
  font-size: 48px;
  margin-bottom: 12px;
}

/* Modal */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgb(0 0 0 / 62%);
  z-index: 1000;
}

.modal-content {
  width: min(90%, 600px);
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  box-shadow: 0 24px 60px rgb(0 0 0 / 42%);
  overflow: hidden;
}

.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 24px;
  border-bottom: 1px solid rgb(255 255 255 / 8%);
}

.modal-header h3 {
  margin: 0;
  color: #fff;
  font-size: 18px;
}

.order-id {
  display: block;
  margin-top: 4px;
  padding: 4px 8px;
  border-radius: 4px;
  background: #211c29;
  color: #b58cff;
  font-family: monospace;
  font-size: 12px;
}

.close-btn {
  padding: 6px;
  border: none;
  border-radius: 6px;
  background: rgb(255 255 255 / 6%);
  color: #bfb6ce;
  font-size: 16px;
  cursor: pointer;
}

.modal-body {
  padding: 24px;
}

.detail-section {
  margin-bottom: 24px;
}

.detail-section:last-child {
  margin-bottom: 0;
}

.detail-section h4 {
  margin: 0 0 16px;
  color: #f6f2ff;
  font-size: 14px;
  font-weight: 600;
}

.detail-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
}

.detail-item {
  display: flex;
  flex-direction: column;
  padding: 12px;
  border-radius: 8px;
  background: #211c29;
}

.detail-item .label {
  color: #8e8798;
  font-size: 12px;
}

.detail-item .value {
  margin-top: 4px;
  color: #f6f2ff;
  font-size: 14px;
  font-weight: 600;
}

.detail-item .value.amount {
  color: #c4b5fd;
}

.detail-item .value.status {
  font-weight: 600;
}

.flow-timeline {
  position: relative;
  padding-left: 20px;
}

.flow-step {
  position: relative;
  padding-bottom: 16px;
}

.flow-step:last-child {
  padding-bottom: 0;
}

.flow-dot {
  position: absolute;
  left: -20px;
  top: 4px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #5c5470;
}

.flow-step.is-active .flow-dot {
  background: #b58cff;
}

.flow-line {
  position: absolute;
  left: -16px;
  top: 14px;
  width: 2px;
  height: calc(100% - 4px);
  background: rgb(255 255 255 / 8%);
}

.flow-step:last-child .flow-line {
  display: none;
}

.flow-step.is-active .flow-line {
  background: #b58cff;
}

.flow-text {
  color: #d8d0e4;
  font-size: 14px;
}

.fee-details {
  display: flex;
  justify-content: space-between;
  margin-top: 16px;
  padding: 16px;
  border-radius: 8px;
  background: #211c29;
}

.fee-details div {
  display: flex;
  flex-direction: column;
}

.fee-details span:first-child {
  color: #8e8798;
  font-size: 12px;
}

.fee-details .fee {
  margin-top: 4px;
  color: #f87171;
  font-size: 16px;
  font-weight: 600;
}

.fee-details .net {
  margin-top: 4px;
  color: #14b8a6;
  font-size: 16px;
  font-weight: 600;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  padding: 16px 24px;
  border-top: 1px solid rgb(255 255 255 / 8%);
}

.btn-secondary {
  padding: 10px 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #d8d0e4;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
}

.btn-secondary:hover {
  background: rgb(103 80 164 / 18%);
  color: #fff;
}

/* Responsive */
@media (max-width: 900px) {
  .stats-row {
    grid-template-columns: repeat(2, 1fr);
  }

  .filters-bar {
    flex-direction: column;
    gap: 12px;
  }

  .orders-table {
    display: block;
    overflow-x: auto;
  }

  .detail-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 640px) {
  .stats-row {
    grid-template-columns: 1fr;
  }

  .detail-grid {
    grid-template-columns: 1fr;
  }

  .search-box input {
    width: 100%;
  }
}
</style>