﻿<script setup lang="ts">
import { ref, computed } from 'vue'

interface User {
  id: string
  name: string
  email: string
  phone: string
  kyc_level: 1 | 2
  kyc_status: 'pending' | 'approved' | 'rejected'
  referrer_id: string | null
  status: 'active' | 'suspended' | 'banned'
  created_at: string
  last_login_at: string
  usdt_balance: number
  troo_balance: number
  locked_amount: number
  total_deposit: number
  total_withdraw: number
}

interface TeamMember {
  id: string
  name: string
  level: string
  phone: string
  investAmount: number
}

interface Order {
  id: string
  package_name: string
  amount: number
  created_at: string
  status: string
}

const users = ref<User[]>([
  { id: 'U001', name: '张三', email: 'zhangsan@example.com', phone: '138****1234', kyc_level: 2, kyc_status: 'approved', referrer_id: 'U000', status: 'active', created_at: '2024-01-15 10:30:00', last_login_at: '2024-03-20 15:45:00', usdt_balance: 5000, troo_balance: 1200, locked_amount: 3100, total_deposit: 10000, total_withdraw: 2000 },
  { id: 'U002', name: '李四', email: 'lisi@example.com', phone: '139****5678', kyc_level: 2, kyc_status: 'approved', referrer_id: 'U001', status: 'active', created_at: '2024-02-20 09:15:00', last_login_at: '2024-03-19 09:20:00', usdt_balance: 15000, troo_balance: 3500, locked_amount: 6200, total_deposit: 30000, total_withdraw: 8000 },
  { id: 'U003', name: '王五', email: 'wangwu@example.com', phone: '137****9012', kyc_level: 1, kyc_status: 'pending', referrer_id: 'U001', status: 'active', created_at: '2024-03-05 14:20:00', last_login_at: '2024-03-20 11:30:00', usdt_balance: 1000, troo_balance: 200, locked_amount: 310, total_deposit: 2000, total_withdraw: 500 },
  { id: 'U004', name: '赵六', email: 'zhaoliu@example.com', phone: '136****3456', kyc_level: 2, kyc_status: 'approved', referrer_id: 'U002', status: 'suspended', created_at: '2024-01-28 16:45:00', last_login_at: '2024-03-18 08:00:00', usdt_balance: 8000, troo_balance: 1800, locked_amount: 4650, total_deposit: 15000, total_withdraw: 3000 },
  { id: 'U005', name: '孙七', email: 'sunqi@example.com', phone: '135****7890', kyc_level: 1, kyc_status: 'approved', referrer_id: 'U002', status: 'active', created_at: '2024-02-10 11:00:00', last_login_at: '2024-03-20 16:20:00', usdt_balance: 3000, troo_balance: 800, locked_amount: 1550, total_deposit: 6000, total_withdraw: 1200 },
  { id: 'U006', name: '周八', email: 'zhouba@example.com', phone: '134****2345', kyc_level: 2, kyc_status: 'rejected', referrer_id: 'U003', status: 'banned', created_at: '2024-03-15 08:30:00', last_login_at: '2024-03-17 10:15:00', usdt_balance: 0, troo_balance: 0, locked_amount: 0, total_deposit: 1000, total_withdraw: 1000 },
])

const searchQuery = ref('')
const statusFilter = ref('all')
const kycFilter = ref('all')
const selectedUser = ref<User | null>(null)
const showTeamModal = ref(false)
const showKycModal = ref(false)
const showDetailDrawer = ref(false)
const teamData = ref<TeamMember[][]>([[], [], [], [], []])
const orders = ref<Order[]>([])

const filteredUsers = computed(() => {
  return users.value.filter(user => {
    const matchesSearch = user.name.includes(searchQuery.value) || 
                         user.email.includes(searchQuery.value) ||
                         user.phone.includes(searchQuery.value) ||
                         user.id.includes(searchQuery.value)
    const matchesStatus = statusFilter.value === 'all' || user.status === statusFilter.value
    const matchesKyc = kycFilter.value === 'all' || user.kyc_status === kycFilter.value
    return matchesSearch && matchesStatus && matchesKyc
  })
})

const statusColors: Record<string, string> = {
  active: '#0d766e',
  suspended: '#9a6700',
  banned: '#b42318',
}

const statusLabels: Record<string, string> = {
  active: '启用',
  suspended: '停权',
  banned: '封禁',
}

const kycColors: Record<string, string> = {
  approved: '#0d766e',
  pending: '#9a6700',
  rejected: '#b42318',
}

const kycLabels: Record<string, string> = {
  approved: '已通过',
  pending: '待处理',
  rejected: '已拒绝',
}

const kycLevelLabels: Record<number, string> = {
  1: 'L1 手机/邮箱验证',
  2: 'L2 证件+人脸+地址',
}

const toggleUserStatus = (user: User) => {
  user.status = user.status === 'active' ? 'suspended' : 'active'
}

const approveKyc = (user: User) => {
  user.kyc_status = 'approved'
  showKycModal.value = false
}

const rejectKyc = (user: User) => {
  user.kyc_status = 'rejected'
  showKycModal.value = false
}

const openTeamModal = (user: User) => {
  selectedUser.value = user
  teamData.value = [
    [{ id: 'T1', name: '会员A', level: 'L2', phone: '138****5555', investAmount: 20000 }],
    [{ id: 'T2', name: '会员B', level: 'L3', phone: '139****6666', investAmount: 30000 }, { id: 'T3', name: '会员C', level: 'L3', phone: '137****7777', investAmount: 25000 }],
    [{ id: 'T4', name: '会员D', level: 'L4', phone: '136****8888', investAmount: 50000 }],
    [{ id: 'T5', name: '会员E', level: 'L5', phone: '135****9999', investAmount: 100000 }, { id: 'T6', name: '会员F', level: 'L5', phone: '134****0000', investAmount: 80000 }],
    [],
  ]
  showTeamModal.value = true
}

const openKycModal = (user: User) => {
  selectedUser.value = user
  showKycModal.value = true
}

const openDetailDrawer = (user: User) => {
  selectedUser.value = user
  orders.value = [
    { id: 'ORD001', package_name: '套餐C', amount: 50000, created_at: '2024-01-15 10:30:00', status: '已完成' },
    { id: 'ORD002', package_name: '套餐D', amount: 30000, created_at: '2024-02-20 14:20:00', status: '已完成' },
  ]
  showDetailDrawer.value = true
}

const closeTeamModal = () => {
  showTeamModal.value = false
}

const closeKycModal = () => {
  showKycModal.value = false
}

const closeDetailDrawer = () => {
  showDetailDrawer.value = false
}
</script>

<template>
  <div class="users-page">
    <!-- Search & Filter -->
    <div class="page-header">
      <div class="header-left">
        <h2>用户管理</h2>
        <p>管理平台会员用户，包括状态管理、KYC审核等功能</p>
      </div>
    </div>

    <!-- Filters -->
    <div class="filters-bar">
      <div class="search-box">
        <i class="ri-search-line" aria-hidden="true"></i>
        <input 
          v-model="searchQuery" 
          type="text" 
          placeholder="搜索用户名、邮箱、手机号、用户ID..."
        />
      </div>
      <div class="filter-group">
        <select v-model="statusFilter">
          <option value="all">全部状态</option>
          <option value="active">启用</option>
          <option value="suspended">停权</option>
          <option value="banned">封禁</option>
        </select>
        <select v-model="kycFilter">
          <option value="all">全部KYC状态</option>
          <option value="approved">已通过</option>
          <option value="pending">待处理</option>
          <option value="rejected">已拒绝</option>
        </select>
      </div>
    </div>

    <!-- Users Table -->
    <div class="table-container">
      <table class="users-table">
        <thead>
          <tr>
            <th>会员账号</th>
            <th>KYC级别</th>
            <th>KYC状态</th>
            <th>推荐人</th>
            <th>当前状态</th>
            <th>注册时间</th>
            <th>最后登入</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="user in filteredUsers" :key="user.id">
            <td>
              <div class="user-info">
                <div class="user-avatar">{{ user.name.slice(0, 1) }}</div>
                <div>
                  <strong class="user-name">{{ user.name }}</strong>
                  <span class="user-email">{{ user.email }}</span>
                  <span class="user-phone">{{ user.phone }}</span>
                </div>
              </div>
            </td>
            <td>
              <span 
                class="level-tag" 
                :class="user.kyc_level === 1 ? 'level-l1' : 'level-l2'"
              >
                {{ user.kyc_level === 1 ? 'L1' : 'L2' }}
              </span>
            </td>
            <td>
              <span 
                class="kyc-tag" 
                :style="{ backgroundColor: kycColors[user.kyc_status] + '20', color: kycColors[user.kyc_status] }"
              >
                {{ kycLabels[user.kyc_status] }}
              </span>
            </td>
            <td>
              <span class="referrer">{{ user.referrer_id || '-' }}</span>
            </td>
            <td>
              <span 
                class="status-tag" 
                :style="{ backgroundColor: statusColors[user.status] + '20', color: statusColors[user.status] }"
              >
                {{ statusLabels[user.status] }}
              </span>
            </td>
            <td>{{ user.created_at }}</td>
            <td>{{ user.last_login_at }}</td>
            <td>
              <div class="actions">
                <button 
                  class="action-btn status-btn" 
                  @click="toggleUserStatus(user)"
                  :title="user.status === 'active' ? '禁用用户' : '启用用户'"
                >
                  <i :class="user.status === 'active' ? 'ri-pause-line' : 'ri-play-line'" aria-hidden="true"></i>
                  <span>{{ user.status === 'active' ? '禁用' : '启用' }}</span>
                </button>
                <button 
                  v-if="user.kyc_status === 'pending'" 
                  class="action-btn kyc-btn" 
                  @click="openKycModal(user)"
                  title="KYC审核"
                >
                  <i class="ri-file-check-line" aria-hidden="true"></i>
                  <span>审核</span>
                </button>
                <button 
                  class="action-btn team-btn" 
                  @click="openTeamModal(user)"
                  title="查看团队"
                >
                  <i class="ri-team-line" aria-hidden="true"></i>
                  <span>团队</span>
                </button>
                <button 
                  class="action-btn detail-btn" 
                  @click="openDetailDrawer(user)"
                  title="查看详情"
                >
                  <i class="ri-eye-line" aria-hidden="true"></i>
                  <span>详情</span>
                </button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      <div v-if="filteredUsers.length === 0" class="empty-state">
        <i class="ri-inbox-line" aria-hidden="true"></i>
        <p>没有找到匹配的用户</p>
      </div>
    </div>

    <!-- Team Modal -->
    <div v-if="showTeamModal" class="modal-overlay" @click="closeTeamModal">
      <div class="modal-content" @click.stop>
        <div class="modal-header">
          <div>
            <h3>{{ selectedUser?.name }} 的团队结构</h3>
            <p>查看该用户的5层下线团队（只读）</p>
          </div>
          <button class="close-btn" @click="closeTeamModal">
            <i class="ri-close-line" aria-hidden="true"></i>
          </button>
        </div>
        <div class="modal-body">
          <div class="team-tree">
            <div class="tree-level" v-for="(level, index) in teamData" :key="index">
              <div class="level-header">
                <span class="level-badge">L{{ index + 1 }}</span>
                <span>{{ level.length }} 人</span>
              </div>
              <div v-if="level.length > 0" class="level-members">
                <div 
                  v-for="member in level" 
                  :key="member.id" 
                  class="member-card"
                >
                  <div class="member-avatar">{{ member.name.slice(0, 1) }}</div>
                  <div class="member-info">
                    <strong class="member-name">{{ member.name }}</strong>
                    <span>{{ member.level }} | {{ member.phone }}</span>
                  </div>
                  <div class="member-amount">
                    ${{ member.investAmount.toLocaleString() }}
                  </div>
                </div>
              </div>
              <div v-else class="empty-level">
                暂无会员
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-secondary" @click="closeTeamModal">关闭</button>
        </div>
      </div>
    </div>

    <!-- KYC审核 Modal -->
    <div v-if="showKycModal" class="modal-overlay" @click="closeKycModal">
      <div class="modal-content kyc-modal" @click.stop>
        <div class="modal-header">
          <div>
            <h3>KYC 审核</h3>
            <p>审核用户 {{ selectedUser?.name }} 的认证资料</p>
          </div>
          <button class="close-btn" @click="closeKycModal">
            <i class="ri-close-line" aria-hidden="true"></i>
          </button>
        </div>
        <div class="modal-body">
          <div class="kyc-content">
            <div class="kyc-section">
              <h4>用户信息</h4>
              <div class="info-grid">
                <div class="info-item">
                  <span class="label">用户ID</span>
                  <span class="value">{{ selectedUser?.id }}</span>
                </div>
                <div class="info-item">
                  <span class="label">姓名</span>
                  <span class="value">{{ selectedUser?.name }}</span>
                </div>
                <div class="info-item">
                  <span class="label">手机号</span>
                  <span class="value">{{ selectedUser?.phone }}</span>
                </div>
                <div class="info-item">
                  <span class="label">邮箱</span>
                  <span class="value">{{ selectedUser?.email }}</span>
                </div>
              </div>
            </div>
            
            <div class="kyc-section">
              <h4>认证资料</h4>
              <div class="docs-grid">
                <div class="doc-item">
                  <div class="doc-placeholder">
                    <i class="ri-id-card-line"></i>
                  </div>
                  <span class="doc-label">身份证正面</span>
                </div>
                <div class="doc-item">
                  <div class="doc-placeholder">
                    <i class="ri-id-card-line"></i>
                  </div>
                  <span class="doc-label">身份证反面</span>
                </div>
                <div class="doc-item">
                  <div class="doc-placeholder">
                    <i class="ri-user-line"></i>
                  </div>
                  <span class="doc-label">人脸识别</span>
                </div>
                <div class="doc-item">
                  <div class="doc-placeholder">
                    <i class="ri-home-line"></i>
                  </div>
                  <span class="doc-label">地址证明</span>
                </div>
              </div>
            </div>

            <div class="kyc-section">
              <h4>审核备注</h4>
              <textarea 
                class="remark-input" 
                placeholder="请输入审核备注（拒绝时必填）"
                rows="3"
              ></textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-secondary" @click="closeKycModal">取消</button>
          <button 
            class="btn-reject" 
            @click="rejectKyc(selectedUser!)"
          >
            拒绝
          </button>
          <button 
            class="btn-approve" 
            @click="approveKyc(selectedUser!)"
          >
            通过
          </button>
        </div>
      </div>
    </div>

    <!-- 详情抽屉 -->
    <div v-if="showDetailDrawer" class="drawer-overlay" @click="closeDetailDrawer">
      <div class="drawer-content" @click.stop>
        <div class="drawer-header">
          <div>
            <h3>{{ selectedUser?.name }} 的详情</h3>
            <p>用户ID: {{ selectedUser?.id }}</p>
          </div>
          <button class="close-btn" @click="closeDetailDrawer">
            <i class="ri-close-line" aria-hidden="true"></i>
          </button>
        </div>
        <div class="drawer-body">
          <!-- 会员资料 -->
          <div class="detail-section">
            <h4><i class="ri-user-line"></i> 会员资料</h4>
            <div class="info-grid">
              <div class="info-item">
                <span class="label">姓名</span>
                <span class="value">{{ selectedUser?.name }}</span>
              </div>
              <div class="info-item">
                <span class="label">手机号</span>
                <span class="value">{{ selectedUser?.phone }}</span>
              </div>
              <div class="info-item">
                <span class="label">邮箱</span>
                <span class="value">{{ selectedUser?.email }}</span>
              </div>
              <div class="info-item">
                <span class="label">KYC级别</span>
                <span class="value">{{ kycLevelLabels[selectedUser?.kyc_level || 1] }}</span>
              </div>
              <div class="info-item">
                <span class="label">KYC状态</span>
                <span 
                  class="value status-value"
                  :style="{ color: kycColors[selectedUser?.kyc_status || 'pending'] }"
                >{{ kycLabels[selectedUser?.kyc_status || 'pending'] }}</span>
              </div>
              <div class="info-item">
                <span class="label">推荐人</span>
                <span class="value">{{ selectedUser?.referrer_id || '-' }}</span>
              </div>
              <div class="info-item">
                <span class="label">当前状态</span>
                <span 
                  class="value status-value"
                  :style="{ color: statusColors[selectedUser?.status || 'active'] }"
                >{{ statusLabels[selectedUser?.status || 'active'] }}</span>
              </div>
              <div class="info-item">
                <span class="label">注册时间</span>
                <span class="value">{{ selectedUser?.created_at }}</span>
              </div>
              <div class="info-item">
                <span class="label">最后登入</span>
                <span class="value">{{ selectedUser?.last_login_at }}</span>
              </div>
            </div>
          </div>

          <!-- 钱包余额 -->
          <div class="detail-section">
            <h4><i class="ri-wallet-line"></i> 钱包余额</h4>
            <div class="wallet-grid">
              <div class="wallet-item">
                <div class="wallet-icon usdt">₮</div>
                <div class="wallet-info">
                  <span class="wallet-label">USDT 可用余额</span>
                  <span class="wallet-value">${{ selectedUser?.usdt_balance.toLocaleString() }}</span>
                </div>
              </div>
              <div class="wallet-item">
                <div class="wallet-icon troo">T</div>
                <div class="wallet-info">
                  <span class="wallet-label">TROO 可用余额</span>
                  <span class="wallet-value">{{ selectedUser?.troo_balance.toLocaleString() }}</span>
                </div>
              </div>
              <div class="wallet-item">
                <div class="wallet-icon locked">🔒</div>
                <div class="wallet-info">
                  <span class="wallet-label">排队锁定金额 (31%)</span>
                  <span class="wallet-value">${{ selectedUser?.locked_amount.toLocaleString() }}</span>
                </div>
              </div>
              <div class="wallet-item">
                <div class="wallet-icon deposit">↗</div>
                <div class="wallet-info">
                  <span class="wallet-label">累计充值</span>
                  <span class="wallet-value">${{ selectedUser?.total_deposit.toLocaleString() }}</span>
                </div>
              </div>
              <div class="wallet-item">
                <div class="wallet-icon withdraw">↘</div>
                <div class="wallet-info">
                  <span class="wallet-label">累计提现</span>
                  <span class="wallet-value">${{ selectedUser?.total_withdraw.toLocaleString() }}</span>
                </div>
              </div>
            </div>
          </div>

          <!-- 订单纪录 -->
          <div class="detail-section">
            <h4><i class="ri-file-text-line"></i> 订单纪录</h4>
            <div class="orders-list">
              <div v-for="order in orders" :key="order.id" class="order-item">
                <div class="order-info">
                  <span class="order-id">{{ order.id }}</span>
                  <span class="order-package">{{ order.package_name }}</span>
                </div>
                <div class="order-amount">${{ order.amount.toLocaleString() }}</div>
                <div class="order-time">{{ order.created_at }}</div>
              </div>
            </div>
          </div>

          <!-- 团队结构 -->
          <div class="detail-section">
            <h4><i class="ri-team-line"></i> 团队结构</h4>
            <div class="mini-team-tree">
              <div 
                v-for="(level, index) in teamData" 
                :key="index" 
                class="mini-level"
              >
                <span class="mini-level-label">L{{ index + 1 }}</span>
                <span class="mini-level-count">{{ level.length }}人</span>
              </div>
            </div>
            <button class="btn-secondary btn-view-team" @click="closeDetailDrawer(); openTeamModal(selectedUser!)">
              查看完整团队结构
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.users-page {
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 100%;
  color: #f6f2ff;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.header-left h2 {
  margin: 0 0 6px;
  color: #fff;
  font-size: 24px;
  font-weight: 700;
}

.header-left p {
  margin: 0;
  color: #8e8798;
  font-size: 14px;
}

/* Filters */
.filters-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background:
    linear-gradient(180deg, rgb(255 255 255 / 3.5%), rgb(255 255 255 / 1.2%)),
    #16121d;
  box-shadow: inset 0 1px 0 rgb(255 255 255 / 4%);
}

.search-box {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #a99ec0;
}

.search-box i {
  color: #b58cff;
  font-size: 14px;
}

.search-box input {
  border: none;
  background: transparent;
  color: #f6f2ff;
  font-size: 14px;
  outline: none;
  width: 200px;
}

.search-box input::placeholder {
  color: #777181;
}

.filter-group {
  display: flex;
  gap: 12px;
}

.filter-group select {
  padding: 10px 16px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #f6f2ff;
  font-size: 14px;
  cursor: pointer;
}

/* Table */
.table-container {
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  box-shadow: 0 18px 50px rgb(0 0 0 / 26%);
  overflow: hidden;
}

.users-table {
  width: 100%;
  border-collapse: collapse;
}

.users-table th {
  padding: 16px;
  text-align: left;
  background: #211c29;
  color: #aaa3b6;
  font-size: 13px;
  font-weight: 600;
}

.users-table td {
  padding: 16px;
  border-bottom: 1px solid rgb(255 255 255 / 6%);
  color: #d8d0e4;
}

.users-table tbody tr {
  transition: background 0.18s ease;
}

.users-table tbody tr:hover {
  background: rgb(103 80 164 / 10%);
}

.user-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.user-avatar {
  display: flex;
  width: 40px;
  height: 40px;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background: linear-gradient(135deg, #6750a4 0%, #6750a4 100%);
  color: #fff;
  font-size: 14px;
  font-weight: 600;
}

.user-info div {
  display: flex;
  flex-direction: column;
}

.user-name {
  color: #fff;
  font-size: 14px;
}

.user-info span {
  color: #8e8798;
  font-size: 12px;
}

.level-tag {
  display: inline-block;
  padding: 4px 10px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
}

.level-tag.level-l1 {
  background: rgba(100, 116, 139, 0.2);
  color: #94a3b8;
}

.level-tag.level-l2 {
  background: rgba(13, 118, 110, 0.2);
  color: #14b8a6;
}

.status-tag,
.kyc-tag {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

.referrer {
  color: #8e8798;
  font-size: 13px;
}

/* Actions */
.actions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.action-btn {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 6px 10px;
  border: none;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
}

.status-btn {
  background: rgba(13, 118, 110, 0.15);
  color: #14b8a6;
}

.status-btn:hover {
  background: rgba(13, 118, 110, 0.25);
}

.kyc-btn {
  background: rgba(154, 103, 0, 0.15);
  color: #f59e0b;
}

.kyc-btn:hover {
  background: rgba(154, 103, 0, 0.25);
}

.team-btn {
  background: rgba(103, 80, 164, 0.15);
  color: #c4b5fd;
}

.team-btn:hover {
  background: rgba(103, 80, 164, 0.25);
}

.detail-btn {
  background: rgba(59, 130, 246, 0.15);
  color: #60a5fa;
}

.detail-btn:hover {
  background: rgba(59, 130, 246, 0.25);
}

/* Empty State */
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 48px;
  color: #8e8798;
}

.empty-state i {
  font-size: 48px;
}

.empty-state p {
  margin-top: 12px;
}

/* Modal */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgb(0 0 0 / 62%);
  z-index: 1000;
}

.modal-content {
  width: min(90%, 800px);
  max-height: 80vh;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  box-shadow: 0 24px 60px rgb(0 0 0 / 42%);
  overflow: hidden;
}

.modal-content.kyc-modal {
  width: min(90%, 600px);
}

.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 24px;
  border-bottom: 1px solid rgb(255 255 255 / 8%);
}

.modal-header h3 {
  margin: 0 0 4px;
  color: #fff;
  font-size: 18px;
}

.modal-header p {
  margin: 0;
  color: #8e8798;
  font-size: 13px;
}

.close-btn {
  padding: 6px;
  border: none;
  border-radius: 6px;
  background: rgb(255 255 255 / 6%);
  color: #bfb6ce;
  font-size: 16px;
  cursor: pointer;
}

.modal-body {
  padding: 24px;
  max-height: 50vh;
  overflow-y: auto;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding: 16px 24px;
  border-top: 1px solid rgb(255 255 255 / 8%);
}

.btn-secondary {
  padding: 10px 20px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #211c29;
  color: #d8d0e4;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-secondary:hover {
  background: rgb(103 80 164 / 18%);
  color: #fff;
}

.btn-approve {
  padding: 10px 20px;
  border: none;
  border-radius: 8px;
  background: linear-gradient(135deg, #0d766e 0%, #0d766e 100%);
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-approve:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 24px rgb(13 118 110 / 30%);
}

.btn-reject {
  padding: 10px 20px;
  border: none;
  border-radius: 8px;
  background: linear-gradient(135deg, #b42318 0%, #b42318 100%);
  color: #fff;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-reject:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 24px rgb(180 35 24 / 30%);
}

/* Team Tree */
.team-tree {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.tree-level {
  padding: 16px;
  border-radius: 8px;
  background: #211c29;
}

.level-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 12px;
}

.level-badge {
  padding: 4px 10px;
  border-radius: 4px;
  background: #6750a4;
  color: #fff;
  font-size: 12px;
  font-weight: 600;
}

.level-header span:last-child {
  color: #aaa3b6;
  font-size: 13px;
}

.level-members {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
}

.member-card {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  border-radius: 8px;
  border: 1px solid rgb(255 255 255 / 8%);
  background: #16121d;
}

.member-avatar {
  display: flex;
  width: 32px;
  height: 32px;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background: rgb(103 80 164 / 22%);
  color: #d8c8ff;
  font-size: 12px;
  font-weight: 600;
}

.member-info {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.member-name {
  color: #fff;
  font-size: 13px;
}

.member-info span {
  color: #8e8798;
  font-size: 11px;
}

.member-amount {
  color: #0d766e;
  font-size: 13px;
  font-weight: 600;
}

.empty-level {
  padding: 16px;
  text-align: center;
  color: #8e8798;
  font-size: 13px;
}

/* KYC Modal Content */
.kyc-content {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.kyc-section {
  background: #211c29;
  border-radius: 8px;
  padding: 20px;
}

.kyc-section h4 {
  margin: 0 0 16px;
  color: #fff;
  font-size: 14px;
  font-weight: 600;
}

.info-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
}

.info-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.info-item .label {
  color: #8e8798;
  font-size: 12px;
}

.info-item .value {
  color: #fff;
  font-size: 14px;
  font-weight: 500;
}

.docs-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
}

.doc-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.doc-placeholder {
  display: flex;
  width: 120px;
  height: 80px;
  align-items: center;
  justify-content: center;
  border: 1px dashed rgb(255 255 255 / 20%);
  border-radius: 8px;
  color: #8e8798;
  font-size: 24px;
}

.doc-label {
  color: #8e8798;
  font-size: 12px;
}

.remark-input {
  width: 100%;
  padding: 12px;
  border: 1px solid rgb(255 255 255 / 8%);
  border-radius: 8px;
  background: #16121d;
  color: #fff;
  font-size: 14px;
  resize: vertical;
  outline: none;
}

.remark-input::placeholder {
  color: #777181;
}

/* Drawer */
.drawer-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgb(0 0 0 / 50%);
  z-index: 1000;
}

.drawer-content {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  width: min(90%, 480px);
  border-left: 1px solid rgb(255 255 255 / 8%);
  background: #16121d;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.drawer-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 24px;
  border-bottom: 1px solid rgb(255 255 255 / 8%);
}

.drawer-header h3 {
  margin: 0 0 4px;
  color: #fff;
  font-size: 18px;
}

.drawer-header p {
  margin: 0;
  color: #8e8798;
  font-size: 13px;
}

.drawer-body {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
}

.detail-section {
  margin-bottom: 24px;
}

.detail-section h4 {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 0 16px;
  color: #fff;
  font-size: 14px;
  font-weight: 600;
}

.detail-section .info-grid {
  grid-template-columns: repeat(3, 1fr);
}

.status-value {
  font-weight: 600;
}

.wallet-grid {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.wallet-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  border-radius: 8px;
  background: #211c29;
}

.wallet-icon {
  display: flex;
  width: 40px;
  height: 40px;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  font-size: 18px;
  font-weight: 700;
}

.wallet-icon.usdt {
  background: rgba(13, 118, 110, 0.2);
  color: #14b8a6;
}

.wallet-icon.troo {
  background: rgba(103, 80, 164, 0.2);
  color: #c4b5fd;
}

.wallet-icon.locked {
  background: rgba(154, 103, 0, 0.2);
  color: #f59e0b;
}

.wallet-icon.deposit {
  background: rgba(34, 197, 94, 0.2);
  color: #4ade80;
}

.wallet-icon.withdraw {
  background: rgba(239, 68, 68, 0.2);
  color: #f87171;
}

.wallet-info {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.wallet-label {
  color: #8e8798;
  font-size: 12px;
}

.wallet-value {
  color: #fff;
  font-size: 16px;
  font-weight: 600;
}

.orders-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.order-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  border-radius: 8px;
  background: #211c29;
}

.order-info {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.order-id {
  color: #8e8798;
  font-size: 11px;
}

.order-package {
  color: #fff;
  font-size: 13px;
  font-weight: 500;
}

.order-amount {
  color: #0d766e;
  font-size: 14px;
  font-weight: 600;
}

.order-time {
  color: #8e8798;
  font-size: 11px;
}

.mini-team-tree {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
}

.mini-level {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 12px;
  border-radius: 8px;
  background: #211c29;
}

.mini-level-label {
  color: #8e8798;
  font-size: 11px;
}

.mini-level-count {
  color: #fff;
  font-size: 18px;
  font-weight: 700;
}

.btn-view-team {
  width: 100%;
}

/* Responsive */
@media (max-width: 900px) {
  .filters-bar {
    flex-direction: column;
    gap: 12px;
  }

  .users-table {
    display: block;
    overflow-x: auto;
  }

  .level-members {
    grid-template-columns: 1fr;
  }

  .actions {
    flex-direction: column;
  }

  .detail-section .info-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 640px) {
  .search-box input {
    width: 100%;
  }

  .info-grid {
    grid-template-columns: 1fr !important;
  }

  .docs-grid {
    grid-template-columns: 1fr;
  }
}
</style>
