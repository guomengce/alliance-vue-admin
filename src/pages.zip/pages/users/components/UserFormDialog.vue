<script setup lang="ts">
import { reactive, watch } from 'vue';
import { User, Message, Phone, UserFilled } from '@element-plus/icons-vue';

interface User {
  id?: number;
  username: string;
  realName: string;
  email: string;
  phone: string;
  role: '管理员' | '普通用户' | '访客';
  status: '正常' | '禁用';
  createTime?: string;
}

const props = defineProps<{
  visible: boolean;
  editData?: User | null;
}>();

const emit = defineEmits<{
  'update:visible': [value: boolean];
  submit: [data: Partial<User>];
}>();

// 表单数据
const form = reactive<User>({
  id: undefined,
  username: '',
  realName: '',
  email: '',
  phone: '',
  role: '普通用户',
  status: '正常',
});

// 表单验证错误
const errors = reactive({
  username: '',
  realName: '',
  email: '',
  phone: '',
});

// 清除错误
const clearErrors = () => {
  errors.username = '';
  errors.realName = '';
  errors.email = '';
  errors.phone = '';
};

// 重置表单
const resetForm = () => {
  form.id = undefined;
  form.username = '';
  form.realName = '';
  form.email = '';
  form.phone = '';
  form.role = '普通用户';
  form.status = '正常';
  clearErrors();
};

// 监听编辑数据变化
watch(
  () => props.editData,
  (newData) => {
    if (newData) {
      form.id = newData.id;
      form.username = newData.username;
      form.realName = newData.realName;
      form.email = newData.email;
      form.phone = newData.phone;
      form.role = newData.role;
      form.status = newData.status;
    } else {
      resetForm();
    }
  }
);

// 监听 visible 变化，关闭时重置表单
watch(
  () => props.visible,
  (newVal) => {
    if (!newVal) {
      resetForm();
    }
  }
);

// 表单验证
const validate = (): boolean => {
  clearErrors();
  let isValid = true;

  if (!form.username.trim()) {
    errors.username = '请输入用户名';
    isValid = false;
  } else if (form.username.length < 3) {
    errors.username = '用户名至少需要3个字符';
    isValid = false;
  }

  if (!form.realName.trim()) {
    errors.realName = '请输入真实姓名';
    isValid = false;
  }

  if (!form.email.trim()) {
    errors.email = '请输入邮箱';
    isValid = false;
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
    errors.email = '请输入有效的邮箱地址';
    isValid = false;
  }

  if (!form.phone.trim()) {
    errors.phone = '请输入手机号';
    isValid = false;
  } else if (!/^1[3-9]\d{9}$/.test(form.phone)) {
    errors.phone = '请输入有效的手机号';
    isValid = false;
  }

  return isValid;
};

// 提交表单
const handleSubmit = () => {
  if (validate()) {
    emit('submit', { ...form });
    emit('update:visible', false);
  }
};

// 关闭对话框
const handleClose = () => {
  emit('update:visible', false);
};
</script>

<template>
  <el-dialog
    :title="form.id ? '编辑用户' : '新增用户'"
    :visible="visible"
    :close-on-click-modal="false"
    width="500px"
    @close="handleClose"
  >
    <el-form :model="form" label-width="100px" class="user-form">
      <!-- 用户名 -->
      <el-form-item label="用户名" :error="errors.username">
        <el-input
          v-model="form.username"
          placeholder="请输入用户名"
          :prefix-icon="User"
        />
      </el-form-item>

      <!-- 真实姓名 -->
      <el-form-item label="真实姓名" :error="errors.realName">
        <el-input
          v-model="form.realName"
          placeholder="请输入真实姓名"
          :prefix-icon="UserFilled"
        />
      </el-form-item>

      <!-- 邮箱 -->
      <el-form-item label="邮箱" :error="errors.email">
        <el-input
          v-model="form.email"
          placeholder="请输入邮箱"
          :prefix-icon="Message"
        />
      </el-form-item>

      <!-- 手机号 -->
      <el-form-item label="手机号" :error="errors.phone">
        <el-input
          v-model="form.phone"
          placeholder="请输入手机号"
          :prefix-icon="Phone"
        />
      </el-form-item>

      <!-- 角色 -->
      <el-form-item label="角色">
        <el-select v-model="form.role" placeholder="请选择角色">
          <el-option label="管理员" value="管理员" />
          <el-option label="普通用户" value="普通用户" />
          <el-option label="访客" value="访客" />
        </el-select>
      </el-form-item>

      <!-- 状态 -->
      <el-form-item label="状态">
        <el-select v-model="form.status" placeholder="请选择状态">
          <el-option label="正常" value="正常" />
          <el-option label="禁用" value="禁用" />
        </el-select>
      </el-form-item>
    </el-form>

    <template #footer>
      <el-button type="default" @click="handleClose">取消</el-button>
      <el-button type="primary" @click="handleSubmit">
        {{ form.id ? '保存修改' : '确认新增' }}
      </el-button>
    </template>
  </el-dialog>
</template>

<style scoped>
.user-form {
  padding: 10px 0;
}

.user-form :deep(.el-form-item) {
  margin-bottom: 20px;
}
</style>
